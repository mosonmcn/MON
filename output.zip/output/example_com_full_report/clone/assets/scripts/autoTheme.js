// ==================== AUTO DARK/LIGHT MODE (Time-Based with Manual Override) ====================

// Check if manual override exists
function hasManualOverride() {
    return localStorage.getItem('theme_manual_override') === 'true';
}

// Apply theme (dark/light) without overriding manual flag
function applyTheme(theme) {
    const html = document.documentElement;
    const body = document.body;
    const themeIcon = document.getElementById('themeIcon');
    
    if (theme === 'dark') {
        html.classList.add('dark');
        html.classList.remove('light');
        body.classList.remove('light-mode');
        if (themeIcon) {
            themeIcon.classList.remove('fa-sun');
            themeIcon.classList.add('fa-moon');
        }
        localStorage.setItem('theme', 'dark');
    } else {
        html.classList.remove('dark');
        html.classList.add('light');
        body.classList.add('light-mode');
        if (themeIcon) {
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-sun');
        }
        localStorage.setItem('theme', 'light');
    }
}

// Get current theme based on time (6 AM = light, 6 PM = dark)
function getTimeBasedTheme() {
    const hour = new Date().getHours();
    // 6:00 to 17:59 = light, 18:00 to 5:59 = dark
    return (hour >= 6 && hour < 18) ? 'light' : 'dark';
}

// Apply time-based theme if no manual override
function applyAutoThemeIfNeeded() {
    if (!hasManualOverride()) {
        const theme = getTimeBasedTheme();
        applyTheme(theme);
        console.log(`Auto theme applied: ${theme} mode at ${new Date().toLocaleTimeString()}`);
    } else {
        console.log('Manual override active, auto theme disabled');
    }
}

// Calculate milliseconds until next 6:00 or 18:00
function getMsUntilNextSwitch() {
    const now = new Date();
    const hour = now.getHours();
    const nextSwitchHour = (hour < 6) ? 6 : (hour < 18) ? 18 : 6; // next 6 or 18
    let nextSwitch = new Date(now);
    nextSwitch.setHours(nextSwitchHour, 0, 0, 0);
    if (nextSwitch <= now) {
        nextSwitch.setDate(nextSwitch.getDate() + 1);
    }
    return nextSwitch - now;
}

// Schedule the next auto switch at 6:00 or 18:00
function scheduleAutoSwitch() {
    const msToSwitch = getMsUntilNextSwitch();
    setTimeout(() => {
        // Re-check manual override at switch time
        if (!hasManualOverride()) {
            const newTheme = getTimeBasedTheme();
            applyTheme(newTheme);
            console.log(`Auto switch triggered: ${newTheme} mode`);
        } else {
            console.log('Manual override present, auto switch skipped');
        }
        // Re-schedule for next switch
        scheduleAutoSwitch();
    }, msToSwitch);
}

// Handle manual toggle (user click on theme button)
function setupManualToggle() {
    const themeToggle = document.getElementById('themeToggle');
    if (!themeToggle) return;
    
    // Remove existing listener to avoid duplicates
    themeToggle.removeEventListener('click', manualToggleHandler);
    themeToggle.addEventListener('click', manualToggleHandler);
}

function manualToggleHandler() {
    const html = document.documentElement;
    const isDark = html.classList.contains('dark');
    const newTheme = isDark ? 'light' : 'dark';
    
    applyTheme(newTheme);
    
    // Set manual override flag
    localStorage.setItem('theme_manual_override', 'true');
    localStorage.setItem('manual_theme', newTheme);
    console.log(`Manual override: switched to ${newTheme} mode`);
}

// Reset manual override (e.g., on logout or by user choice)
function resetManualOverride() {
    localStorage.removeItem('theme_manual_override');
    localStorage.removeItem('manual_theme');
    applyAutoThemeIfNeeded();
    console.log('Manual override reset, auto theme reactivated');
}

// Initialize auto theme system
function initAutoTheme() {
    // First, check if there's a manual override from previous session
    const manualTheme = localStorage.getItem('manual_theme');
    if (manualTheme && localStorage.getItem('theme_manual_override') === 'true') {
        // Respect previous manual override
        applyTheme(manualTheme);
        console.log(`Restored manual override: ${manualTheme} mode`);
    } else {
        // No override, apply time-based theme
        applyAutoThemeIfNeeded();
    }
    
    // Schedule auto switches at 6:00 and 18:00
    scheduleAutoSwitch();
    
    // Attach manual toggle listener
    setupManualToggle();
}

// Export functions for external use (optional)
window.autoTheme = {
    init: initAutoTheme,
    reset: resetManualOverride,
    applyAuto: applyAutoThemeIfNeeded
};