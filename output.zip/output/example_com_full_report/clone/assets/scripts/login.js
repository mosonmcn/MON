// ── 1. Password Toggle ──
function togglePassword() {
    const pw = document.getElementById('password');
    const icon = document.getElementById('eyeIcon');
    pw.type = pw.type === 'password' ? 'text' : 'password';
    icon.classList.toggle('fa-eye');
    icon.classList.toggle('fa-eye-slash');
}

// ── 2. Storage functions (localStorage only) ──
function setAuthData(userData) {
    localStorage.setItem('MD_USER_DATA', JSON.stringify(userData));
    localStorage.setItem('MD_AUTH_STATUS', 'true');
}

// ── 3. DOM Ready ──
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const loginBtn = document.getElementById('loginBtn');
    const messageDisplay = document.getElementById('messageDisplay');
    const formTokenInput = document.getElementById('formToken');

    // ── 4. Security Handshake (CSRF) ──
    async function fetchAuthToken() {
        try {
            const res = await fetch('../api/get_auth_token.php');
            const data = await res.json();
            if (data.status === 'success') {
                formTokenInput.value = data.token;
                document.getElementById('loadingState').classList.add('hidden');
                document.getElementById('loginContainer').classList.remove('hidden');
                document.getElementById('loginContainer').classList.add('animate-fade-in');
            }
        } catch (e) {
            messageDisplay.innerHTML = "⚠️ Connection error. Please refresh.";
            document.getElementById('loadingState').classList.add('hidden');
            document.getElementById('loginContainer').classList.remove('hidden');
            document.getElementById('loginContainer').classList.add('animate-fade-in');
        }
    }
    fetchAuthToken();

    // ── 5. Submission ──
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // UI Loading State
        loginBtn.disabled = true;
        loginBtn.innerHTML = '<div class="spinner"></div><span>Verifying...</span>';
        messageDisplay.textContent = "";

        try {
            const res = await fetch('../api/user/auth/login.php', {
                method: 'POST',
                credentials: 'same-origin',
                body: new FormData(loginForm)
            });

            const result = await res.json();

            if (result.status === 'success') {
                // Save full response to localStorage (must include dataPrices & transactions)
                const fullData = {
                    userDetails: result.userDetails,
                    transactions: result.transactions || [],
                    dataPrices: result.dataPrices || {}
                };
                setAuthData(fullData);
                
                messageDisplay.className = "text-center text-emerald-500 font-bold mt-2";
                messageDisplay.textContent = "✅ Login Successful!";
                
                setTimeout(() => window.location.href = '/dashboard/', 1000);
            } else {
                throw new Error(result.message || "Invalid credentials.");
            }
        } catch (err) {
            messageDisplay.className = "text-center text-red-500 font-bold mt-2";
            messageDisplay.textContent = "❌ " + err.message;
            
            // Shake effect on error
            document.getElementById('wrapUser').classList.add('error');
            document.getElementById('wrapPassword').classList.add('error');
            setTimeout(() => {
                document.getElementById('wrapUser').classList.remove('error');
                document.getElementById('wrapPassword').classList.remove('error');
            }, 500);

            loginBtn.disabled = false;
            loginBtn.innerHTML = '<span>Sign In</span><i class="fas fa-sign-in-alt"></i>';
            fetchAuthToken(); // Refresh CSRF token
        }
    });
});