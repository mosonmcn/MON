// ==================== PayFlux AI – Frontend AI Chat (Full) ====================
// This file replaces the old AI chat code from other.js

// State management
let awaitingConfirmation = false;
let currentPendingId = null;
let currentPendingAction = null;

// DOM elements
let chatInput, sendBtn, voiceBtn, chatMessages;

// ==================== Initialization ====================
function initPayFluxAI() {
    chatInput = document.getElementById('chatInput');
    sendBtn = document.getElementById('sendChatBtn');
    voiceBtn = document.getElementById('voiceBtn');
    chatMessages = document.getElementById('chatMessages');
    
    if (!chatInput || !sendBtn) return;
    
    chatInput.addEventListener('input', () => updateSendButtonState());
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey && !sendBtn.disabled && !awaitingConfirmation) {
            e.preventDefault();
            sendChatMessage();
        }
    });
    
    sendBtn.addEventListener('click', sendChatMessage);
    
    if (voiceBtn) {
        initVoiceRecognition();
        voiceBtn.addEventListener('click', toggleVoiceRecording);
    }
    
    updateSendButtonState();
    window.addEventListener('online', () => showToast('Back online!', 'success'));
    window.addEventListener('offline', () => showToast('No internet connection', 'error'));
}

function updateSendButtonState() {
    const isOnline = navigator.onLine;
    const hasText = chatInput.value.trim().length > 0;
    sendBtn.disabled = !isOnline || !hasText || awaitingConfirmation;
    if (sendBtn.disabled) sendBtn.classList.add('opacity-50', 'cursor-not-allowed');
    else sendBtn.classList.remove('opacity-50', 'cursor-not-allowed');
}

// ==================== Chat UI Helpers ====================
function addUserMessage(text) {
    const div = document.createElement('div');
    div.className = 'flex items-start space-x-3 justify-end mb-2';
    div.innerHTML = `
        <div class="bg-violet-600 text-white p-3 rounded-l-xl rounded-br-xl shadow-sm text-sm max-w-[85%]">${escapeHtml(text)}</div>
        <div class="h-8 w-8 rounded-full bg-gray-300 dark:bg-gray-600 flex-shrink-0 flex items-center justify-center text-xs"><i class="fas fa-user"></i></div>
    `;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function addAssistantMessage(text, isHtml = false) {
    const div = document.createElement('div');
    div.className = 'flex items-start space-x-3 mb-2';
    div.innerHTML = `
        <div class="h-8 w-8 rounded-full bg-violet-600 text-white flex-shrink-0 flex items-center justify-center text-xs"><i class="fas fa-robot"></i></div>
        <div class="bg-white dark:bg-gray-700 p-3 rounded-r-xl rounded-bl-xl shadow-sm text-sm max-w-[85%] border border-gray-100 dark:border-gray-600">
            ${isHtml ? text : escapeHtml(text)}
        </div>
    `;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    if (typeof speakText === 'function') speakText(text);
}

function addTypingIndicator() {
    const div = document.createElement('div');
    div.id = 'typing-indicator';
    div.className = 'flex items-start space-x-3 mb-2';
    div.innerHTML = `
        <div class="h-8 w-8 rounded-full bg-violet-600 text-white flex-shrink-0 flex items-center justify-center text-xs"><i class="fas fa-robot"></i></div>
        <div class="bg-white dark:bg-gray-700 p-3 rounded-r-xl rounded-bl-xl shadow-sm text-sm text-gray-500">
            <i class="fas fa-spinner fa-spin mr-2"></i> Yana tunani...
        </div>
    `;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function removeTypingIndicator() {
    const el = document.getElementById('typing-indicator');
    if (el) el.remove();
}

function showInlineInput(promptText, inputType, callback) {
    const container = document.createElement('div');
    container.className = 'flex items-start space-x-3 mb-2';
    container.innerHTML = `
        <div class="h-8 w-8 rounded-full bg-violet-600 text-white flex-shrink-0 flex items-center justify-center text-xs"><i class="fas fa-lock"></i></div>
        <div class="bg-white dark:bg-gray-700 p-3 rounded-r-xl rounded-bl-xl shadow-sm text-sm max-w-[85%] border border-gray-100 dark:border-gray-600">
            <p class="text-gray-800 dark:text-gray-200 mb-2">${escapeHtml(promptText)}</p>
            <div class="flex gap-2">
                <input type="${inputType === 'pin' ? 'password' : 'text'}" id="inlineInput" maxlength="${inputType === 'pin' ? 4 : 6}" placeholder="${inputType === 'pin' ? '••••' : 'Enter code'}" class="flex-1 px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-800 focus:ring-2 focus:ring-violet-600 outline-none text-center">
                <button id="inlineSubmit" class="bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-lg transition">Submit</button>
            </div>
        </div>
    `;
    chatMessages.appendChild(container);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    const input = container.querySelector('#inlineInput');
    const btn = container.querySelector('#inlineSubmit');
    const onSubmit = () => {
        const val = input.value.trim();
        if (!val || (inputType === 'pin' && !/^\d{4}$/.test(val))) {
            showToast(`${inputType.toUpperCase()} must be ${inputType === 'pin' ? '4 digits' : 'non-empty'}`, 'error');
            return;
        }
        container.remove();
        callback(val);
    };
    btn.addEventListener('click', onSubmit);
    input.addEventListener('keypress', (e) => { if (e.key === 'Enter') onSubmit(); });
    input.focus();
}

function showConfirmButtons(promptText, onConfirm, onCancel) {
    const container = document.createElement('div');
    container.className = 'flex items-start space-x-3 mb-2';
    container.innerHTML = `
        <div class="h-8 w-8 rounded-full bg-violet-600 text-white flex-shrink-0 flex items-center justify-center text-xs"><i class="fas fa-question-circle"></i></div>
        <div class="bg-white dark:bg-gray-700 p-3 rounded-r-xl rounded-bl-xl shadow-sm text-sm max-w-[85%] border border-gray-100 dark:border-gray-600">
            <p class="text-gray-800 dark:text-gray-200 mb-3">${escapeHtml(promptText)}</p>
            <div class="flex gap-3">
                <button id="confirmYes" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition">Confirm</button>
                <button id="confirmNo" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition">Cancel</button>
            </div>
        </div>
    `;
    chatMessages.appendChild(container);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    const yesBtn = container.querySelector('#confirmYes');
    const noBtn = container.querySelector('#confirmNo');
    yesBtn.addEventListener('click', () => { container.remove(); onConfirm(); });
    noBtn.addEventListener('click', () => { container.remove(); onCancel(); });
}

// ==================== Main Send Message ====================
// ==================== Main Send Message ====================
async function sendChatMessage() {
    if (awaitingConfirmation) {
        showToast('Please complete the current request first.', 'error');
        return;
    }
    const message = chatInput.value.trim();
    if (!message) return;
    
    // Store original message for potential restore
    const originalMessage = message;
    
    // Disable send button, clear input, add user message to chat
    sendBtn.disabled = true;
    chatInput.value = '';
    updateSendButtonState();
    addUserMessage(message);
    addTypingIndicator();
    
    try {
        const userData = loadUserData();
        const token = userData?.userDetails?.token || '';
        const response = await fetch('/api/ai/chat.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message, token, limit: 10 })
        });
        const result = await response.json();
        removeTypingIndicator();
        
        if (result.status === 'success') {
            let reply = result.message || 'An gama.';
            if (result.new_balance) reply += ` Sabon balance: ₦${result.new_balance.toLocaleString()}`;
            addAssistantMessage(reply);
            if (result.new_balance && typeof loadUserDataToUI === 'function') {
                await window.fetchUserData?.();
                loadUserDataToUI();
            }
        } 
        else if (result.status === 'confirm') {
            awaitingConfirmation = true;
            currentPendingId = result.pending_id;
            currentPendingAction = result.action;
            showConfirmButtons(result.message || 'Do you want to proceed?', async () => {
                await sendConfirmation('confirm', 'yes');
            }, () => {
                addAssistantMessage('Transaction cancelled.');
                awaitingConfirmation = false;
                currentPendingId = null;
                currentPendingAction = null;
            });
        }
        else if (result.status === 'pending_verification') {
            const action = result.action;
            if (action === '/verify/pin') {
                awaitingConfirmation = true;
                currentPendingId = result.pending_id;
                showInlineInput(result.message || 'Enter your 4-digit PIN:', 'pin', async (pin) => {
                    await sendConfirmation('pin', pin);
                });
            } else if (action === '/verify/otp') {
                awaitingConfirmation = true;
                showInlineInput(result.message || 'Enter OTP sent to your email:', 'otp', async (otp) => {
                    await sendConfirmation('otp', otp);
                });
            } else {
                addAssistantMessage(result.message || 'Verification required.');
            }
        }
        else if (result.status === 'need_more_info') {
            addAssistantMessage(result.message || 'Please provide more details.');
        }
        
        else if (result.status === 'payment_link') {
    // Show a special interactive message (like WhatsApp)
    const paymentHtml = `
        <div class="bg-white dark:bg-gray-800 rounded-xl p-4 border border-purple-500/30 shadow-lg">
            <div class="flex items-center mb-3">
                <i class="fas fa-credit-card text-purple-500 text-xl mr-2"></i>
                <span class="font-bold text-purple-500">Paystack Payment</span>
            </div>
            <p class="text-gray-700 dark:text-gray-300 mb-3">${escapeHtml(result.message)}</p>
            <a href="${escapeHtml(result.payment_link)}" target="_blank" 
               class="inline-flex items-center justify-center w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-2 px-4 rounded-lg transition shadow-md">
                <i class="fas fa-external-link-alt mr-2"></i> Pay Now
            </a>
        </div>
    `;
    addAssistantMessage(paymentHtml, true);
    // Optional: also speak the message
    if (typeof speakText === 'function') speakText(result.message);
}

        else if (result.status === 'error') {
            // API returned error – restore user input and remove user message
            const userMsgDiv = document.querySelector('#chatMessages .justify-end:last-child');
            if (userMsgDiv) userMsgDiv.remove();
            chatInput.value = originalMessage;
            showToast(result.message || 'An error occurred. Please try again.', 'error');
            updateSendButtonState();
        }
        else {
            // Unknown response – treat as error
            const userMsgDiv = document.querySelector('#chatMessages .justify-end:last-child');
            if (userMsgDiv) userMsgDiv.remove();
            chatInput.value = originalMessage;
            showToast('Sorry, I did not understand that.', 'error');
            updateSendButtonState();
        }
    } catch (err) {
        removeTypingIndicator();
        // Network or fetch error – restore user message and remove user message from chat
        const userMsgDiv = document.querySelector('#chatMessages .justify-end:last-child');
        if (userMsgDiv) userMsgDiv.remove();
        chatInput.value = originalMessage;
        showToast('Network error. Please check your connection.', 'error');
        updateSendButtonState();
        console.error(err);
    } finally {
        sendBtn.disabled = false;
        updateSendButtonState();
    }
}

async function sendConfirmation(type, value) {
    if (!currentPendingId) {
        addAssistantMessage('Confirmation error: missing pending ID.');
        awaitingConfirmation = false;
        return;
    }
    
    addTypingIndicator();
    try {
        const userData = loadUserData();
        const token = userData?.userDetails?.token || '';
        const response = await fetch('../api/ai/confirm.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                token,
                pending_id: currentPendingId,
                type,
                value
            })
        });
        const result = await response.json();
        removeTypingIndicator();
        if (result.status === 'success') {
            let msg = result.message || 'Transaction completed.';
            if (result.new_balance) msg += ` New balance: ₦${result.new_balance.toLocaleString()}`;
            addAssistantMessage(msg);
            if (result.new_balance && typeof loadUserDataToUI === 'function') {
                await window.fetchUserData?.();
                loadUserDataToUI();
            }
        } else {
            addAssistantMessage(result.message || 'Confirmation failed.');
        }
    } catch (err) {
        removeTypingIndicator();
        addAssistantMessage('Network error during confirmation.');
        console.error(err);
    } finally {
        awaitingConfirmation = false;
        currentPendingId = null;
        currentPendingAction = null;
    }
}

// ==================== Voice Recognition ====================
let recognition = null;
let isRecording = false;

function initVoiceRecognition() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        console.warn('Speech recognition not supported');
        if (voiceBtn) voiceBtn.style.display = 'none';
        return;
    }
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'ha-NG';
    
    recognition.onstart = () => {
        isRecording = true;
        if (voiceBtn) {
            voiceBtn.classList.add('recording');
            voiceBtn.innerHTML = '<i class="fas fa-microphone-slash"></i>';
        }
        showToast('Recording... speak now', 'info');
    };
    recognition.onend = () => {
        isRecording = false;
        if (voiceBtn) {
            voiceBtn.classList.remove('recording');
            voiceBtn.innerHTML = '<i class="fas fa-microphone"></i>';
        }
    };
    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        if (chatInput) {
            chatInput.value = transcript;
            if (!awaitingConfirmation) sendChatMessage();
        }
    };
    recognition.onerror = (event) => {
        console.error('Speech error', event.error);
        showToast('Voice recognition error: ' + event.error, 'error');
        if (voiceBtn) voiceBtn.classList.remove('recording');
        voiceBtn.innerHTML = '<i class="fas fa-microphone"></i>';
        isRecording = false;
    };
}

function toggleVoiceRecording() {
    if (!recognition) {
        showToast('Voice not supported in this browser', 'error');
        return;
    }
    if (isRecording) recognition.stop();
    else recognition.start();
}

function speakText(text) {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ha-NG';
    utterance.rate = 0.9;
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find(v => v.lang.includes('ha') || v.name.includes('Google UK English Female'));
    if (preferred) utterance.voice = preferred;
    window.speechSynthesis.speak(utterance);
}

// ==================== Clear Chat ====================
window.clearChat = function() {
    if (chatMessages) {
        chatMessages.innerHTML = `<div class="flex items-start space-x-3">
            <div class="h-8 w-8 rounded-full bg-violet-600 text-white flex-shrink-0 flex items-center justify-center text-xs"><i class="fas fa-robot"></i></div>
            <div class="bg-white dark:bg-gray-700 p-3 rounded-r-xl rounded-bl-xl shadow-sm text-sm max-w-[85%] border border-gray-100 dark:border-gray-600">
                <p class="text-gray-800 dark:text-gray-200 leading-relaxed">
                    👋 Sannu! Ni ne PayFlux AI — Smart Assistant ɗinka.<br>
                    Ba sai ka danna abubuwa da yawa ba…<br>
                    Ka gaya min kawai abin da kake so, zan yi maka shi.<br><br>
                    <span class="font-semibold">Misalai:</span><br>
                    🟢 “Siyan 1GB MTN yanzu”<br>
                    🟢 “Aika airtime ₦100 zuwa 080…”<br>
                    🟢 "Siya min data 1GB gobe karfe 10 da rabi zuwa wannan lambar 08089..."<br>
                    🟢 “Nawa ne balance dina?”<br><br>
                    ⚡ Fast. Simple. Smart.<br>
                    Ka fara yanzu 👇
                </p>
            </div>
        </div>`;
    }
    awaitingConfirmation = false;
    currentPendingId = null;
    currentPendingAction = null;
};

function showToast(msg, type = 'info') {
    const toast = document.getElementById('toast');
    if (!toast) return;
    const toastMsg = document.getElementById('toastMsg');
    const icon = toast.querySelector('i');
    toastMsg.textContent = msg;
    let bg = 'bg-gray-800';
    let iconClass = 'fas fa-info-circle text-blue-400';
    if (type === 'success') {
        bg = 'bg-purple-700';
        iconClass = 'fas fa-check-circle text-purple-400';
    } else if (type === 'error') {
        bg = 'bg-red-600';
        iconClass = 'fas fa-exclamation-circle text-red-400';
    }
    toast.querySelector('div').className = `${bg} text-white px-6 py-3 rounded-lg shadow-2xl flex items-center space-x-3`;
    icon.className = iconClass;
    toast.classList.remove('translate-y-20', 'opacity-0');
    setTimeout(() => toast.classList.add('translate-y-20', 'opacity-0'), 3000);
}

// ==================== Bootstrap ====================
document.addEventListener('DOMContentLoaded', () => {
    initPayFluxAI();
    window.sendChatMessage = sendChatMessage;
    window.toggleVoiceRecording = toggleVoiceRecording;
    window.speakText = speakText;
});