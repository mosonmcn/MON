// ==================== TOAST NOTIFICATIONS ====================
function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    if (!toast) {
        console.warn('Toast element not found.');
        return;
    }
    const messageEl = document.getElementById('toastMsg');
    const iconEl = toast.querySelector('i');
    messageEl.textContent = message;
    
    let bgClass = 'bg-gray-800';
    let iconClass = 'fas fa-info-circle text-blue-400';
    
    if (type === 'success') {
        bgClass = 'bg-purple-700';
        iconClass = 'fas fa-check-circle text-purple-400';
    } else if (type === 'error') {
        bgClass = 'bg-red-600';
        iconClass = 'fas fa-exclamation-circle text-red-400';
    }
    
    const toastInner = toast.querySelector('div');
    toastInner.className = `${bgClass} text-white px-6 py-3 rounded-lg shadow-2xl flex items-center space-x-3`;
    iconEl.className = iconClass;
    
    toast.classList.remove('translate-y-20', 'opacity-0');
    setTimeout(() => {
        toast.classList.add('translate-y-20', 'opacity-0');
    }, 3000);
}