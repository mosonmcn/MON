// ==================== DARK MODE THEME ====================
function initTheme() {
    const themeToggle = document.getElementById('themeToggle');
    const html = document.documentElement;
    
    // Load saved theme or system preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        html.classList.add('dark');
    } else if (savedTheme === 'light') {
        html.classList.remove('dark');
    } else {
        // Check system preference
        if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
            html.classList.add('dark');
        } else {
            html.classList.remove('dark');
        }
    }
    
    // Update icon visibility
    updateThemeIcon();
    
    // Add event listener to toggle button
    if (themeToggle) {
        // Remove old listener to avoid duplicates
        themeToggle.removeEventListener('click', handleThemeToggle);
        themeToggle.addEventListener('click', handleThemeToggle);
        console.log('Theme toggle listener attached');
    } else {
        console.error('Theme toggle button not found! Check id="themeToggle"');
    }
}

function handleThemeToggle() {
    const html = document.documentElement;
    const isDark = html.classList.contains('dark');
    
    if (isDark) {
        html.classList.remove('dark');
        localStorage.setItem('theme', 'light');
    } else {
        html.classList.add('dark');
        localStorage.setItem('theme', 'dark');
    }
    
    updateThemeIcon();
    
    // Optional toast notification
    if (typeof showToast === 'function') {
        showToast(localStorage.getItem('theme') === 'dark' ? 'Dark mode enabled' : 'Light mode enabled', 'info');
    }
}

function updateThemeIcon() {
    const themeToggle = document.getElementById('themeToggle');
    if (!themeToggle) return;
    
    const isDark = document.documentElement.classList.contains('dark');
    const moonIcon = themeToggle.querySelector('.fa-moon');
    const sunIcon = themeToggle.querySelector('.fa-sun');
    
    if (moonIcon && sunIcon) {
        if (isDark) {
            moonIcon.classList.add('hidden');
            sunIcon.classList.remove('hidden');
        } else {
            moonIcon.classList.remove('hidden');
            sunIcon.classList.add('hidden');
        }
    }
}

// Auto-run when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
});