// ==================== AUTHENTICATION (LOCALSTORAGE ONLY) ====================

function checkAuthAndRedirect() {
    // Check localStorage for auth status and user data
    const authStatus = localStorage.getItem('MD_AUTH_STATUS');
    const userData = localStorage.getItem('MD_USER_DATA');
    
    if (!authStatus || authStatus !== 'true' || !userData) {
        console.warn('No valid auth data found, redirecting to login');
        window.location.href = '../login';
        return false;
    }
    
    console.log('Auth valid, user is logged in');
    return true;
}

function logout() {
    if (confirm('Logout?')) {
        // Clear localStorage
        localStorage.removeItem('MD_USER_DATA');
        localStorage.removeItem('MD_AUTH_STATUS');
        localStorage.removeItem('MD_APP_DATA');
        
        // Clear sessionStorage for good measure
        sessionStorage.clear();
        
        // Optional: Clear any cookies that might remain (if any)
        document.cookie.split(";").forEach(c => {
            document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
        });
        
        showToast("Logged out successfully", "success");
        setTimeout(() => window.location.href = '../login', 1000);
    }
}

// Helper to set auth status after login
function setAuthStatus(authenticated) {
    localStorage.setItem('MD_AUTH_STATUS', authenticated ? 'true' : 'false');
}

// Helper to check if user is authenticated (returns boolean)
function isAuthenticated() {
    return localStorage.getItem('MD_AUTH_STATUS') === 'true' && localStorage.getItem('MD_USER_DATA') !== null;
}