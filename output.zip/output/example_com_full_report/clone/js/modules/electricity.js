// js/modules/electricity.js
// Electricity Module - Handles all electricity bill payments

/**
 * Load electricity providers (Discos) from API
 */
async function loadElectricityProviders() {
    const select = document.getElementById('elecProvider');
    if (!select) return;

    try {
        const token = getCookie('auth_token');
        if (!token) {
            showToast('Please login first', 'error');
            return;
        }

        const response = await fetch('/api/electric/providers.php?token=' + encodeURIComponent(token), {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        const result = await response.json();

        if (result.status === 'success' && result.data) {
            select.innerHTML = '<option value="">Select Provider</option>';
            result.data.forEach(provider => {
                const option = document.createElement('option');
                option.value = provider.id;
                option.textContent = provider.name;
                select.appendChild(option);
            });
        } else {
            showToast('Failed to load providers: ' + (result.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error loading electricity providers:', error);
        showToast('Error loading providers. Please refresh.', 'error');
    }
}

/**
 * Verify electricity meter number
 */
async function verifyElectricityMeter() {
    const providerId = document.getElementById('elecProvider').value;
    const meter = document.getElementById('elecMeter').value.trim();
    const infoDiv = document.getElementById('elecMeterInfo');

    if (!providerId) {
        showToast('Please select a provider first', 'warning');
        return;
    }

    if (!meter || meter.length < 5) {
        showToast('Please enter a valid meter number', 'warning');
        return;
    }

    try {
        const token = getCookie('auth_token');
        const formData = new URLSearchParams();
        formData.append('provider_id', providerId);
        formData.append('meter_number', meter);
        formData.append('token', token);

        const response = await fetch('/api/electric/verify.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: formData
        });

        const result = await response.json();

        if (result.status === 'successful' && result.data && result.data.is_valid) {
            document.getElementById('elecCustomerName').textContent = result.data.customer_name || 'N/A';
            document.getElementById('elecMeterType').textContent = result.data.meter_type || 'N/A';
            infoDiv.classList.remove('hidden');
            showToast('Meter verified successfully!', 'success');
        } else {
            infoDiv.classList.add('hidden');
            showToast('Invalid meter number: ' + (result.message || 'Verification failed'), 'error');
        }
    } catch (error) {
        console.error('Error verifying meter:', error);
        showToast('Error verifying meter. Please try again.', 'error');
    }
}

/**
 * Update electricity summary when amount changes
 */
function updateElectricitySummary() {
    const amountSelect = document.getElementById('elecAmount');
    const amount = parseFloat(amountSelect.value) || 0;
    const markup = 5; // 5%
    const charges = amount * (markup / 100);
    const total = amount + charges;

    document.getElementById('elecBaseAmount').textContent = `₦${amount.toFixed(2)}`;
    document.getElementById('elecCharges').textContent = `₦${charges.toFixed(2)}`;
    document.getElementById('elecTotal').textContent = `₦${total.toFixed(2)}`;
}

/**
 * Handle electricity purchase form submission
 */
async function handleElectricityPurchase(event) {
    event.preventDefault();

    const providerId = document.getElementById('elecProvider').value;
    const meter = document.getElementById('elecMeter').value.trim();
    const amount = parseFloat(document.getElementById('elecAmount').value) || 0;
    const pin = document.getElementById('elecPin').value.trim();

    // Validate all fields
    if (!providerId) {
        showToast('Please select a provider', 'warning');
        return;
    }
    if (!meter || meter.length < 5) {
        showToast('Please enter a valid meter number', 'warning');
        return;
    }
    if (amount < 100) {
        showToast('Minimum amount is ₦100', 'warning');
        return;
    }
    if (!pin || pin.length !== 4) {
        showToast('Please enter your 4-digit transaction PIN', 'warning');
        return;
    }

    // Disable button
    const submitBtn = document.querySelector('#electricityForm button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

    try {
        const token = getCookie('auth_token');
        const formData = new URLSearchParams();
        formData.append('provider_id', providerId);
        formData.append('meter_number', meter);
        formData.append('amount', amount);
        formData.append('pin', pin);
        formData.append('token', token);

        const response = await fetch('/api/electric/buy.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: formData
        });

        const result = await response.json();

        if (result.status === 'success') {
            showToast('✅ Electricity payment successful!', 'success');
            // Update balance
            if (window.updateBalanceDisplay) {
                window.updateBalanceDisplay(result.new_balance);
            }
            // Show token to user
            if (result.token) {
                showDialog('Electricity Token', `
                    <div class="text-center">
                        <p class="text-sm text-gray-600 dark:text-gray-300">Your electricity token:</p>
                        <div class="bg-gray-100 dark:bg-gray-800 p-4 rounded-xl my-3 font-mono text-2xl font-bold text-primary">
                            ${result.token}
                        </div>
                        <p class="text-sm text-gray-600 dark:text-gray-300">Units: ${result.units || 'N/A'}</p>
                        <p class="text-sm text-gray-600 dark:text-gray-300">Customer: ${result.customer_name || 'N/A'}</p>
                    </div>
                `);
            }
            showTransactionDetails(result);
        } else {
            showToast('❌ ' + (result.message || 'Payment failed'), 'error');
        }
    } catch (error) {
        console.error('Error purchasing electricity:', error);
        showToast('Error processing payment. Please try again.', 'error');
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-bolt"></i> Pay Now';
    }
}

// Auto-load providers when electricity section becomes active
document.addEventListener('DOMContentLoaded', function() {
    const elecSection = document.getElementById('electricity');
    if (elecSection) {
        const observer = new MutationObserver(function(mutations) {
            if (elecSection.classList.contains('active')) {
                loadElectricityProviders();
                updateElectricitySummary();
                observer.disconnect();
            }
        });
        observer.observe(elecSection, { attributes: true, attributeFilter: ['class'] });
    }
});