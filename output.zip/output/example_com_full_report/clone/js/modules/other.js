// ==================== OTHER FUNCTIONS (LOCALSTORAGE ONLY) ====================
// This file now handles only profile, password, and PIN settings.
// AI Chat has been moved to payfluxai.js

window.updateProfile = async function(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const name = document.getElementById('profName').value;
    const email = document.getElementById('profEmail').value;
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
    
    try {
        const result = await window.updateUserProfile(name, email);
        if (result.status === 'success') {
            await window.fetchUserData();
            loadUserDataToUI();
            showDialog('Profile Updated', 'Your profile has been updated successfully.', 'success');
        } else {
            throw new Error(result.message);
        }
    } catch (error) {
        showDialog('Error', error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = 'Save Changes';
    }
};

window.changePassword = async function(e) {
    const newPass = document.getElementById('newPassword').value;
    if (!newPass || newPass.length < 8) {
        showToast('Password must be at least 8 characters', 'error');
        return;
    }
    try {
        const result = await window.changeUserPassword(newPass);
        if (result.status === 'success') {
            document.getElementById('newPassword').value = '';
            showDialog('Password Changed', 'Your password has been updated.', 'success');
        } else {
            throw new Error(result.message);
        }
    } catch (error) {
        showDialog('Error', error.message, 'error');
    }
};

window.setPin = async function(e) {
    const pin = document.getElementById('txnPin').value;
    if (!/^\d{4}$/.test(pin)) {
        showToast('PIN must be exactly 4 digits', 'error');
        return;
    }
    try {
        const result = await window.setTransactionPin(pin);
        if (result.status === 'success') {
            document.getElementById('txnPin').value = '';
            showDialog('PIN Set', 'Transaction PIN has been set successfully.', 'success');
        } else {
            throw new Error(result.message);
        }
    } catch (error) {
        showDialog('Error', error.message, 'error');
    }
};