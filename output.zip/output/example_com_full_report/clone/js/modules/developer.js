// developer.js - Handles API Key, Webhook, Data Plans Export

(function() {
    // Helper to load user token from localStorage
    function getUserToken() {
        const userDataRaw = localStorage.getItem('MD_USER_DATA');
        if (userDataRaw) {
            try {
                const userData = JSON.parse(userDataRaw);
                return userData.userDetails?.token || null;
            } catch(e) { return null; }
        }
        return null;
    }

    // Store separate API key (not the same as user token)
    let currentApiKey = localStorage.getItem('PAYFLUX_API_KEY') || '';
    let apiKeyVisible = false;

    // DOM elements
    const apiKeyInput = document.getElementById('apiKeyDisplayDev');
    const toggleEyeBtn = document.getElementById('toggleApiKeyVisibility');
    const eyeIcon = document.getElementById('apiKeyEyeIcon');
    const copyBtn = document.getElementById('copyApiKeyDevBtn');
    const regenerateBtn = document.getElementById('regenerateApiKeyBtn');
    const saveWebhookBtn = document.getElementById('saveWebhookDevBtn');
    const webhookUrlInput = document.getElementById('webhookUrlDev');
    const webhookSavedMsg = document.getElementById('webhookSavedMsg');
    const docsBtn = document.getElementById('goToDocsBtn');
    const markupInput = document.getElementById('markupPercent');
    const copySqlBtn = document.getElementById('copySqlBtn');
    const downloadCsvBtn = document.getElementById('downloadCsvBtn');

    // ==================== API Key Functions ====================
    async function fetchApiKeyFromBackend(pin) {
        // Replace with actual API call
        // Example using existing apiCall
        if (typeof apiCall === 'function') {
            try {
                const result = await apiCall('developer/get_api_key.php', 'POST', { pin });
                if (result.status === 'success') {
                    return result.api_key;
                } else {
                    throw new Error(result.message || 'Failed to fetch API key');
                }
            } catch(err) {
                throw err;
            }
        } else {
            // Mock for demo - simulate backend call
            return new Promise((resolve, reject) => {
                setTimeout(() => {
                    if (pin === '1234') {
                        const mockKey = 'pk_live_' + Math.random().toString(36).substr(2, 24);
                        resolve(mockKey);
                    } else {
                        reject(new Error('Invalid PIN'));
                    }
                }, 500);
            });
        }
    }

    async function regenerateApiKey(pin) {
        if (typeof apiCall === 'function') {
            const result = await apiCall('developer/regenerate_api_key.php', 'POST', { pin });
            if (result.status === 'success') {
                return result.api_key;
            } else {
                throw new Error(result.message || 'Failed to regenerate');
            }
        } else {
            return new Promise((resolve, reject) => {
                setTimeout(() => {
                    if (pin === '1234') {
                        const newKey = 'pk_live_new_' + Math.random().toString(36).substr(2, 20);
                        resolve(newKey);
                    } else {
                        reject(new Error('Invalid PIN'));
                    }
                }, 500);
            });
        }
    }

    function updateApiKeyDisplay() {
        if (apiKeyInput) {
            if (apiKeyVisible && currentApiKey) {
                apiKeyInput.value = currentApiKey;
                apiKeyInput.type = 'text';
                if (eyeIcon) eyeIcon.classList.replace('fa-eye-slash', 'fa-eye');
            } else {
                apiKeyInput.value = currentApiKey ? '••••••••••••••••' : 'No API key set';
                apiKeyInput.type = 'password';
                if (eyeIcon) eyeIcon.classList.replace('fa-eye', 'fa-eye-slash');
            }
        }
    }

    // Show PIN modal then fetch API key
    function showApiKeyWithPin() {
        if (typeof showPinModal === 'function') {
            showPinModal(async (pin) => {
                if (!pin) return;
                try {
                    const apiKey = await fetchApiKeyFromBackend(pin);
                    if (apiKey) {
                        currentApiKey = apiKey;
                        localStorage.setItem('PAYFLUX_API_KEY', currentApiKey);
                        apiKeyVisible = true;
                        updateApiKeyDisplay();
                        showToast('API key retrieved', 'success');
                        // Optionally hide after few seconds? Not necessary.
                    }
                } catch(err) {
                    showToast(err.message || 'Failed to get API key', 'error');
                    apiKeyVisible = false;
                    updateApiKeyDisplay();
                }
            });
        } else {
            showToast('PIN modal not available', 'error');
        }
    }

    function regenerateApiKeyWithPin() {
        if (typeof showPinModal === 'function') {
            showPinModal(async (pin) => {
                if (!pin) return;
                try {
                    const newKey = await regenerateApiKey(pin);
                    if (newKey) {
                        currentApiKey = newKey;
                        localStorage.setItem('PAYFLUX_API_KEY', currentApiKey);
                        apiKeyVisible = true;
                        updateApiKeyDisplay();
                        showToast('API key regenerated successfully', 'success');
                    }
                } catch(err) {
                    showToast(err.message || 'Failed to regenerate', 'error');
                }
            });
        } else {
            showToast('PIN modal not available', 'error');
        }
    }

    function copyApiKey() {
        if (currentApiKey) {
            navigator.clipboard.writeText(currentApiKey);
            showToast('API Key copied to clipboard', 'success');
        } else {
            showToast('No API key to copy. Please show or regenerate first.', 'error');
        }
    }

    function toggleApiKeyVisibility() {
        if (!currentApiKey) {
            // If no API key stored, prompt to show with PIN
            showApiKeyWithPin();
        } else {
            if (apiKeyVisible) {
                apiKeyVisible = false;
                updateApiKeyDisplay();
            } else {
                // If hidden, ask for PIN to reveal
                if (typeof showPinModal === 'function') {
                    showPinModal(async (pin) => {
                        if (!pin) return;
                        // Verify PIN before showing (optional: we could just show since we already have key)
                        // But for security, re-verify with backend?
                        // We'll just show the stored key after PIN confirmation.
                        // To be safe, you can call fetchApiKeyFromBackend again to ensure key is valid.
                        try {
                            // Optionally re-fetch to confirm PIN
                            const verifiedKey = await fetchApiKeyFromBackend(pin);
                            if (verifiedKey) {
                                currentApiKey = verifiedKey;
                                localStorage.setItem('PAYFLUX_API_KEY', currentApiKey);
                                apiKeyVisible = true;
                                updateApiKeyDisplay();
                                showToast('API key visible', 'success');
                            }
                        } catch(err) {
                            showToast('Invalid PIN or verification failed', 'error');
                        }
                    });
                }
            }
        }
    }

    // ==================== Webhook ====================
    function loadWebhookUrl() {
        const saved = localStorage.getItem('payflux_webhook_url');
        if (webhookUrlInput && saved) webhookUrlInput.value = saved;
    }

    function saveWebhookUrl() {
        const url = webhookUrlInput.value.trim();
        if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
            localStorage.setItem('payflux_webhook_url', url);
            if (webhookSavedMsg) {
                webhookSavedMsg.classList.remove('hidden');
                setTimeout(() => webhookSavedMsg.classList.add('hidden'), 2000);
            }
            showToast('Webhook URL saved', 'success');
        } else {
            showToast('Enter valid URL (http:// or https://)', 'error');
        }
    }

    // ==================== Data Plans Table & Export ====================
    let currentPlans = [];
    let currentMarkup = 0;

    function loadPlansData() {
        const userDataRaw = localStorage.getItem('MD_USER_DATA');
        let dataPrices = {};
        if (userDataRaw) {
            try {
                const userData = JSON.parse(userDataRaw);
                dataPrices = userData.dataPrices || {};
            } catch(e) {}
        }
        currentMarkup = parseFloat(markupInput?.value) || 0;
        renderPlansTable(dataPrices, currentMarkup);
    }

    function renderPlansTable(dataPrices, markup) {
        const tbody = document.getElementById('dataPlansTableBody');
        if (!tbody) return;
        if (!dataPrices || Object.keys(dataPrices).length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center py-6 text-gray-400">No plans available</td></tr>';
            currentPlans = [];
            return;
        }
        let html = '';
        let exportData = [];
        let idCounter = 1;
        for (const [network, plans] of Object.entries(dataPrices)) {
            if (!Array.isArray(plans)) continue;
            for (const plan of plans) {
                const planId = plan.id || idCounter++;
                const planCode = plan.plan_code || plan.code || `PLAN_${planId}`;
                const planName = plan.plan || plan.name;
                const planType = plan.plan_type || (plan.type ? plan.type.toUpperCase() : 'SME');
                const cost = typeof plan.price === 'number' ? plan.price : parseFloat(plan.price) || 0;
                const selling = cost * (1 + markup / 100);
                const validity = plan.validity || '30 days';
                let networkDisplay = network.toUpperCase();
                if (networkDisplay === 'MTN') networkDisplay = 'MTN';
                else if (networkDisplay === 'GLO') networkDisplay = 'GLO';
                else if (networkDisplay === '9MOBILE') networkDisplay = '9MOBILE';
                else if (networkDisplay === 'AIRTEL') networkDisplay = 'AIRTEL';
                else networkDisplay = network;
                html += `<tr>
                    <td class="px-3 py-2 font-mono">${planId}</td>
                    <td class="px-3 py-2 font-mono">${escapeHtml(planCode)}</td>
                    <td class="px-3 py-2">${networkDisplay}</td>
                    <td class="px-3 py-2">${escapeHtml(planName)}</td>
                    <td class="px-3 py-2">${planType}</td>
                    <td class="px-3 py-2 text-right">₦${cost.toFixed(2)}</td>
                    <td class="px-3 py-2 text-right font-bold text-primary">₦${selling.toFixed(2)}</td>
                    <td class="px-3 py-2 text-xs">${validity}</td>
                </tr>`;
                exportData.push({
                    id: planId,
                    plan_code: planCode,
                    network: networkDisplay,
                    plan_name: planName,
                    plan_type: planType,
                    cost_price: cost,
                    selling_price: selling,
                    validity: validity,
                    markup_percent: markup
                });
            }
        }
        tbody.innerHTML = html;
        currentPlans = exportData;
    }

    function generateCustomSQL() {
        if (!currentPlans.length) return null;
        const tableName = document.getElementById('sqlTableName')?.value.trim() || 'data_plans';
        const idCol = document.getElementById('colId')?.value.trim() || 'id';
        const planCodeCol = document.getElementById('colPlanCode')?.value.trim() || 'plan_code';
        const networkCol = document.getElementById('colNetwork')?.value.trim() || 'network';
        const planNameCol = document.getElementById('colPlanName')?.value.trim() || 'plan_name';
        const planTypeCol = document.getElementById('colPlanType')?.value.trim() || 'plan_type';
        const priceCol = document.getElementById('colSellingPrice')?.value.trim() || 'selling_price';
        const validityCol = document.getElementById('colValidity')?.value.trim() || 'validity';
        const createdAtCol = document.getElementById('colCreatedAt')?.value.trim() || 'created_at';

        let sql = `-- Data plans export with ${currentPlans[0]?.markup_percent || 0}% markup\n`;
        sql += `-- Generated on ${new Date().toISOString()}\n\n`;
        sql += `INSERT INTO \`${tableName}\` (${idCol}, ${planCodeCol}, ${networkCol}, ${planNameCol}, ${planTypeCol}, ${priceCol}, ${validityCol}, ${createdAtCol}) VALUES\n`;
        const rows = currentPlans.map(p => {
            const escapedName = p.plan_name.replace(/'/g, "''");
            const escapedCode = p.plan_code.replace(/'/g, "''");
            const price = p.selling_price.toFixed(2);
            const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
            return `(${p.id}, '${escapedCode}', '${p.network}', '${escapedName}', '${p.plan_type}', ${price}, '${p.validity}', '${now}')`;
        });
        sql += rows.join(',\n') + ';\n';
        return sql;
    }

    function copySQL() {
        const sql = generateCustomSQL();
        if (sql) {
            navigator.clipboard.writeText(sql);
            showToast('SQL copied to clipboard', 'success');
        } else {
            showToast('No data to export', 'error');
        }
    }

    function downloadCSV() {
        if (!currentPlans.length) {
            showToast('No data to export', 'error');
            return;
        }
        const headers = ['ID', 'Plan Code', 'Network', 'Plan Name', 'Plan Type', 'Cost Price (₦)', 'Selling Price (₦)', 'Validity', 'Markup (%)'];
        const rows = currentPlans.map(p => [
            p.id, p.plan_code, p.network, p.plan_name, p.plan_type, p.cost_price.toFixed(2), p.selling_price.toFixed(2), p.validity, p.markup_percent
        ]);
        const csvContent = [headers, ...rows].map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.href = url;
        link.download = `data_plans_${Date.now()}.csv`;
        link.click();
        URL.revokeObjectURL(url);
        showToast('CSV downloaded', 'success');
    }

    // Helper
    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });
    }

    // ==================== Initialization ====================
    function initDeveloperSection() {
        loadWebhookUrl();
        loadPlansData();

        if (toggleEyeBtn) toggleEyeBtn.addEventListener('click', toggleApiKeyVisibility);
        if (regenerateBtn) regenerateBtn.addEventListener('click', regenerateApiKeyWithPin);
        if (copyBtn) copyBtn.addEventListener('click', copyApiKey);
        if (saveWebhookBtn) saveWebhookBtn.addEventListener('click', saveWebhookUrl);
        if (docsBtn) docsBtn.addEventListener('click', () => window.location.href = '/document');
        if (markupInput) markupInput.addEventListener('input', loadPlansData);
        if (copySqlBtn) copySqlBtn.addEventListener('click', copySQL);
        if (downloadCsvBtn) downloadCsvBtn.addEventListener('click', downloadCSV);
    }

    // Auto-init when developer section becomes visible
    const devSection = document.getElementById('developer');
    if (devSection) {
        const observer = new MutationObserver(() => {
            if (devSection.classList.contains('active')) {
                initDeveloperSection();
                observer.disconnect(); // run once
            }
        });
        observer.observe(devSection, { attributes: true, attributeFilter: ['class'] });
        if (devSection.classList.contains('active')) initDeveloperSection();
    }
})();