// ==================== SECURITY FUNCTIONS ====================

// Toggle SET PIN vs CHANGE PIN form based on is_setpin from localStorage
function updateSecurityForms() {
    const userData = loadUserData();
    const isSetPin = userData?.userDetails?.is_setpin === true;

    const setPinForm   = document.getElementById('setPinForm');
    const changePinForm = document.getElementById('changePinForm');

    if (setPinForm)    setPinForm.style.display    = isSetPin ? 'none'  : 'block';
    if (changePinForm) changePinForm.style.display = isSetPin ? 'block' : 'none';
}

// ── Set PIN (first time only) ──
window.submitSetPin = async function() {
    const pin     = document.getElementById('setPinInput')?.value?.trim();
    const confirm = document.getElementById('setPinConfirm')?.value?.trim();

    if (!pin || !/^\d{4}$/.test(pin)) {
        showToast('PIN must be exactly 4 digits', 'error'); return;
    }
    if (confirm !== undefined && confirm !== pin) {
        showToast('PINs do not match', 'error'); return;
    }

    try {
        const result = await window.setTransactionPin(pin);
        if (result.status === 'success') {
            // Refresh from server so is_setpin updates
            await window.fetchUserData();
            loadUserDataToUI();
            if (document.getElementById('setPinInput'))
                document.getElementById('setPinInput').value = '';
            if (document.getElementById('setPinConfirm'))
                document.getElementById('setPinConfirm').value = '';
            showDialog('PIN Set ✅', result.message || 'Transaction PIN set successfully.', 'success');
        } else {
            throw new Error(result.message || 'Failed to set PIN');
        }
    } catch(err) {
        showDialog('Error', err.message, 'error');
    }
};

// ── Change existing PIN ──
window.submitChangePin = async function() {
    const oldPin = document.getElementById('oldPinInput')?.value?.trim();
    const newPin = document.getElementById('newPinInput')?.value?.trim();

    if (!oldPin || !/^\d{4}$/.test(oldPin)) {
        showToast('Current PIN must be 4 digits', 'error'); return;
    }
    if (!newPin || !/^\d{4}$/.test(newPin)) {
        showToast('New PIN must be 4 digits', 'error'); return;
    }
    if (oldPin === newPin) {
        showToast('New PIN cannot be same as current PIN', 'error'); return;
    }

    try {
        const result = await window.changeTransactionPin(oldPin, newPin);
        if (result.status === 'success') {
            await window.fetchUserData();
            loadUserDataToUI();
            if (document.getElementById('oldPinInput')) document.getElementById('oldPinInput').value = '';
            if (document.getElementById('newPinInput')) document.getElementById('newPinInput').value = '';
            showDialog('PIN Changed ✅', result.message || 'Transaction PIN changed successfully.', 'success');
        } else {
            throw new Error(result.message || 'Failed to change PIN');
        }
    } catch(err) {
        showDialog('Error', err.message, 'error');
    }
};

// ── Change Password ──
window.submitChangePassword = async function() {
    const currentPwd = document.getElementById('currentPassword')?.value;
    const newPwd     = document.getElementById('newPassword')?.value;
    const confirmPwd = document.getElementById('confirmPassword')?.value;

    if (!currentPwd || !newPwd || !confirmPwd) {
        showToast('Please fill all fields', 'error'); return;
    }
    if (newPwd.length < 6) {
        showToast('New password must be at least 6 characters', 'error'); return;
    }
    if (newPwd !== confirmPwd) {
        showToast('New passwords do not match', 'error'); return;
    }

    try {
        // changeUserPassword(currentPassword, newPassword) — fixed in mainapi.js
        const result = await window.changeUserPassword(currentPwd, newPwd);
        if (result.status === 'success') {
            if (document.getElementById('currentPassword')) document.getElementById('currentPassword').value = '';
            if (document.getElementById('newPassword'))     document.getElementById('newPassword').value     = '';
            if (document.getElementById('confirmPassword')) document.getElementById('confirmPassword').value = '';
            showDialog('Password Changed ✅', 'Your password has been updated successfully.', 'success');
        } else {
            throw new Error(result.message || 'Failed to change password');
        }
    } catch(err) {
        showDialog('Error', err.message, 'error');
    }
};

// Alias for backward compatibility
window.changePassword = window.submitChangePassword;
