// ==================== BALANCE HIDE/SHOW ====================
let isBalanceHidden = false;

function toggleBalanceVisibility() {
    isBalanceHidden = !isBalanceHidden;
    localStorage.setItem('balance_hidden', isBalanceHidden ? 'true' : 'false');
    updateAllBalancesDisplay();
    updateBalanceIcons();
    showToast(isBalanceHidden ? 'Balance hidden' : 'Balance visible', 'info');
}

function updateAllBalancesDisplay() {
    const balanceElements = document.querySelectorAll('.balance-value');
    const actualBalance = getCurrentBalance();
    
    balanceElements.forEach(el => {
        if (isBalanceHidden) {
            if (!el.hasAttribute('data-original-balance')) {
                el.setAttribute('data-original-balance', el.textContent);
            }
            el.textContent = '••••••';
            el.classList.add('balance-hidden');
        } else {
            const original = el.getAttribute('data-original-balance');
            if (original) {
                el.textContent = original;
            } else {
                el.textContent = actualBalance;
            }
            el.classList.remove('balance-hidden');
        }
    });
}

function updateBalanceIcons() {
    const icons = ['balanceToggleIcon', 'dashBalanceIcon', 'walletBalanceIcon'];
    icons.forEach(iconId => {
        const icon = document.getElementById(iconId);
        if (icon) {
            icon.className = isBalanceHidden ? 'fas fa-eye text-sm' : 'fas fa-eye-slash text-sm';
        }
    });
}

function getCurrentBalance() {
    // Always read from localStorage (source of truth), not DOM
    const userData = loadUserData();
    const balance  = userData?.userDetails?.balance;
    if (balance !== undefined && balance !== null) {
        return formatCurrency(parseFloat(balance));
    }
    // Fallback: DOM attribute
    const dashBalance = document.getElementById('dashBalance');
    const stored = dashBalance?.getAttribute('data-original-balance');
    return stored || '₦0.00';
}

function loadBalanceVisibilityPreference() {
    const saved = localStorage.getItem('balance_hidden');
    if (saved === 'true') {
        isBalanceHidden = true;
        updateAllBalancesDisplay();
        updateBalanceIcons();
    }
}