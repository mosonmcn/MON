// ==================== TRANSACTIONS (LOCALSTORAGE ONLY) ====================

function renderTransactions(transactions) {
    const tbody = document.getElementById('transTableBody');
    if (!tbody) return;
    
    if (!transactions || transactions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center py-8 text-gray-500">No transactions yet</td></tr>';
        return;
    }
    
    let html = '';
    transactions.forEach((t, index) => {
        const service = t.service || (t.description?.includes('Data') ? 'Data' : (t.description?.includes('Airtime') ? 'Airtime' : 'Transaction'));
        let color = 'text-blue-500';
        let icon = 'fa-exchange-alt';
        
        switch(service.toLowerCase()) {
            case 'data': color = 'text-blue-500'; icon = 'fa-wifi'; break;
            case 'airtime': color = 'text-purple-500'; icon = 'fa-phone-alt'; break;
            case 'electricity': color = 'text-yellow-500'; icon = 'fa-bolt'; break;
            case 'cable': case 'cable tv': color = 'text-pink-500'; icon = 'fa-tv'; break;
            case 'funding': case 'wallet funding': color = 'text-green-500'; icon = 'fa-money-bill-wave'; break;
            default: color = 'text-gray-500'; icon = 'fa-receipt';
        }
        
        const amount = t.amount || 0;
        const isDebit = (service?.toLowerCase() !== 'funding' && service?.toLowerCase() !== 'wallet funding');
        const amountPrefix = isDebit ? '-' : '+';
        const amountClass = isDebit ? 'text-red-500' : 'text-green-500';
        
        const formattedDate = formatDate(t.date);
        const status = t.status || 'Successful';
        const statusClass = status === 'Successful' || status === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700';
        
        let additionalInfo = '';
        if (t.token) additionalInfo = `<div class="text-xs text-gray-400 mt-1">Token: ${t.token.substring(0, 20)}${t.token.length > 20 ? '...' : ''}</div>`;
        if (t.reference) additionalInfo += `<div class="text-xs text-gray-400">Ref: ${t.reference}</div>`;
        
        const escapedDesc = escapeHtml(t.description || '-');
        const escapedService = escapeHtml(service);
        
        html += `<tr class="hover:bg-gray-50 dark:hover:bg-gray-800 transition cursor-pointer transaction-row" 
                    data-id="${t.id || index}"
                    data-reference="${escapeHtml(t.reference || '')}"
                    data-service="${escapedService}"
                    data-description="${escapedDesc}"
                    data-amount="${amount}"
                    data-old-balance="${t.old_balance || 0}"
                    data-new-balance="${t.new_balance || 0}"
                    data-status="${status}"
                    data-date="${t.date || ''}"
                    data-token="${escapeHtml(t.token || '')}"
                    onclick="showTransactionModalFromRow(this)">
            <td class="px-6 py-4">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center ${color}">
                        <i class="fas ${icon} text-sm"></i>
                    </div>
                    <div>
                        <span class="font-medium capitalize">${escapedService}</span>
                        ${additionalInfo}
                    </div>
                </div>
               </td>
            <td class="px-6 py-4 text-gray-500 dark:text-gray-400">${escapedDesc}</td>
            <td class="px-6 py-4 text-gray-500 dark:text-gray-400 text-xs">${formattedDate}</td>
            <td class="px-6 py-4"><span class="px-2 py-1 text-xs rounded-full ${statusClass} font-bold">${status}</span></td>
            <td class="px-6 py-4 text-right font-bold ${amountClass}">${amountPrefix}₦${Math.abs(amount).toLocaleString('en-NG', { minimumFractionDigits: 2 })}</td>
          </tr>`;
    });
    tbody.innerHTML = html;
}

// ==================== DOWNLOAD TRANSACTIONS ====================
function downloadTransactionsAsCSV() {
    const userData = loadUserData();
    const transactions = userData?.transactions || [];
    
    if (!transactions || transactions.length === 0) {
        showToast('No transactions to download', 'error');
        return;
    }
    
    const headers = ['ID', 'Reference', 'Service', 'Description', 'Amount', 'Old Balance', 'New Balance', 'Status', 'Date', 'Token'];
    const rows = transactions.map(t => [
        t.id || '',
        t.reference || '',
        t.service || '',
        `"${(t.description || '').replace(/"/g, '""')}"`,
        t.amount || 0,
        t.old_balance || 0,
        t.new_balance || 0,
        t.status || '',
        t.date || '',
        t.token || ''
    ]);
    
    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `transactions_${new Date().toISOString().slice(0,19).replace(/:/g, '-')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('Transactions downloaded successfully', 'success');
}

// Store current transaction globally for download
let currentTransactionForDownload = null;

function showTransactionModalFromRow(row) {
    if (event) event.stopPropagation();
    
    const transaction = {
        id: row.getAttribute('data-id'),
        reference: row.getAttribute('data-reference'),
        service: row.getAttribute('data-service'),
        description: row.getAttribute('data-description'),
        amount: parseFloat(row.getAttribute('data-amount')),
        old_balance: parseFloat(row.getAttribute('data-old-balance')),
        new_balance: parseFloat(row.getAttribute('data-new-balance')),
        status: row.getAttribute('data-status'),
        date: row.getAttribute('data-date'),
        token: row.getAttribute('data-token')
    };
    
    if (!transaction.id && transaction.id !== 0) {
        console.warn('No transaction data found');
        return;
    }
    
    currentTransactionForDownload = transaction;
    
    const modal = document.getElementById('transactionModal');
    const modalContent = document.getElementById('transactionDetails');
    if (!modal || !modalContent) return;
    
    let detailsHtml = `
        <div class="grid grid-cols-2 gap-3 text-sm">
            <div class="text-gray-500 dark:text-gray-400 font-medium">Transaction ID:</div>
            <div class="font-mono text-gray-800 dark:text-white">${transaction.id || 'N/A'}</div>
            
            <div class="text-gray-500 dark:text-gray-400 font-medium">Reference:</div>
            <div class="font-mono text-gray-800 dark:text-white break-all">${transaction.reference || 'N/A'}</div>
            
            <div class="text-gray-500 dark:text-gray-400 font-medium">Service:</div>
            <div class="capitalize text-gray-800 dark:text-white">${transaction.service || 'N/A'}</div>
            
            <div class="text-gray-500 dark:text-gray-400 font-medium">Description:</div>
            <div class="text-gray-800 dark:text-white break-words">${transaction.description || 'N/A'}</div>
            
            <div class="text-gray-500 dark:text-gray-400 font-medium">Amount:</div>
            <div class="font-bold ${transaction.amount < 0 ? 'text-red-500' : 'text-green-500'}">
                ${transaction.amount < 0 ? '-' : '+'}₦${Math.abs(transaction.amount).toLocaleString('en-NG', { minimumFractionDigits: 2 })}
            </div>
            
            <div class="text-gray-500 dark:text-gray-400 font-medium">Old Balance:</div>
            <div class="text-gray-800 dark:text-white">₦${(transaction.old_balance || 0).toLocaleString('en-NG', { minimumFractionDigits: 2 })}</div>
            
            <div class="text-gray-500 dark:text-gray-400 font-medium">New Balance:</div>
            <div class="text-gray-800 dark:text-white">₦${(transaction.new_balance || 0).toLocaleString('en-NG', { minimumFractionDigits: 2 })}</div>
            
            <div class="text-gray-500 dark:text-gray-400 font-medium">Status:</div>
            <div><span class="px-2 py-1 text-xs rounded-full ${transaction.status === 'Successful' || transaction.status === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}">${transaction.status || 'N/A'}</span></div>
            
            <div class="text-gray-500 dark:text-gray-400 font-medium">Date & Time:</div>
            <div class="text-gray-800 dark:text-white">${transaction.date || 'N/A'}</div>`;
    
    if (transaction.token && transaction.token !== 'null' && transaction.token !== '') {
        detailsHtml += `
            <div class="text-gray-500 dark:text-gray-400 font-medium">Token:</div>
            <div class="font-mono text-xs break-all bg-gray-100 dark:bg-gray-800 p-2 rounded-lg text-gray-800 dark:text-white">${transaction.token}</div>`;
    }
    detailsHtml += `</div>`;
    modalContent.innerHTML = detailsHtml;
    
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    const innerModal = document.getElementById('modalContent');
    if (innerModal) {
        innerModal.classList.remove('scale-95', 'opacity-0');
        innerModal.classList.add('scale-100', 'opacity-100');
    }
}

function downloadSingleTransaction() {
    if (!currentTransactionForDownload) {
        showToast('No transaction data to download', 'error');
        return;
    }
    
    const transaction = currentTransactionForDownload;
    let content = '=== TRANSACTION DETAILS ===\n\n';
    content += `Transaction ID: ${transaction.id}\n`;
    content += `Reference: ${transaction.reference}\n`;
    content += `Service: ${transaction.service}\n`;
    content += `Description: ${transaction.description}\n`;
    content += `Amount: ${transaction.amount < 0 ? '-' : '+'}₦${Math.abs(transaction.amount).toLocaleString('en-NG', { minimumFractionDigits: 2 })}\n`;
    content += `Old Balance: ₦${(transaction.old_balance || 0).toLocaleString('en-NG', { minimumFractionDigits: 2 })}\n`;
    content += `New Balance: ₦${(transaction.new_balance || 0).toLocaleString('en-NG', { minimumFractionDigits: 2 })}\n`;
    content += `Status: ${transaction.status}\n`;
    content += `Date: ${transaction.date}\n`;
    if (transaction.token && transaction.token !== 'null' && transaction.token !== '') {
        content += `Token: ${transaction.token}\n`;
    }
    content += `\n--- End of transaction ---\n`;
    
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    const filename = `transaction_${transaction.id || transaction.reference || 'export'}.txt`;
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast('Transaction downloaded successfully', 'success');
}

function closeTransactionModal(event) {
    if (event) event.stopPropagation();
    const modal = document.getElementById('transactionModal');
    const innerModal = document.getElementById('modalContent');
    if (!modal) return;
    if (innerModal) {
        innerModal.classList.add('scale-95', 'opacity-0');
    }
    setTimeout(() => {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        currentTransactionForDownload = null;
    }, 200);
}