// ==================== DATA PURCHASE MODULE ====================

// PIN Modal Functions
let pendingPurchaseData = null;

function showPinModal(callback) {
    let pinModal = document.getElementById('pinModal');
    if (!pinModal) {
        pinModal = document.createElement('div');
        pinModal.id = 'pinModal';
        pinModal.className = 'fixed inset-0 z-50 hidden items-center justify-center bg-black/60 backdrop-blur-sm transition-all duration-300';
        pinModal.innerHTML = `
            <div class="bg-white dark:bg-darkCard rounded-2xl shadow-2xl max-w-sm w-full mx-4 transform transition-all duration-300 scale-95 opacity-0" id="pinModalContent">
                <div class="p-6">
                    <div class="text-center mb-4">
                        <div class="w-16 h-16 mx-auto bg-violet-100 dark:bg-violet-900/30 rounded-full flex items-center justify-center mb-3">
                            <i class="fas fa-lock text-2xl text-violet-600 dark:text-violet-400"></i>
                        </div>
                        <h3 class="text-xl font-bold text-gray-800 dark:text-white">Enter Transaction PIN</h3>
                        <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">Please enter your 4-digit PIN to confirm this purchase</p>
                    </div>
                    <div class="mb-6">
                        <input type="password" id="pinInput" maxlength="4" placeholder="• • • •" 
                               class="w-full text-center text-2xl tracking-widest px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-800 focus:ring-2 focus:ring-violet-600 outline-none transition"
                               inputmode="numeric" pattern="[0-9]*">
                    </div>
                    <div class="flex gap-3">
                        <button id="pinCancelBtn" class="flex-1 px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white rounded-lg hover:bg-gray-300 transition">Cancel</button>
                        <button id="pinConfirmBtn" class="flex-1 px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-lg transition">Confirm</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(pinModal);
    }
    
    const modal = document.getElementById('pinModal');
    const content = document.getElementById('pinModalContent');
    const pinInput = document.getElementById('pinInput');
    const confirmBtn = document.getElementById('pinConfirmBtn');
    const cancelBtn = document.getElementById('pinCancelBtn');
    
    pinInput.value = '';
    
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    setTimeout(() => {
        content.classList.remove('scale-95', 'opacity-0');
        content.classList.add('scale-100', 'opacity-100');
        pinInput.focus();
    }, 10);
    
    const onConfirm = () => {
        const pin = pinInput.value.trim();
        if (!pin || !/^\d{4}$/.test(pin)) {
            showToast('PIN must be 4 digits', 'error');
            return;
        }
        closePinModal();
        callback(pin);
    };
    
    const onCancel = () => {
        closePinModal();
        callback(null);
    };
    
    confirmBtn.onclick = onConfirm;
    cancelBtn.onclick = onCancel;
    pinInput.onkeypress = (e) => {
        if (e.key === 'Enter') onConfirm();
    };
    
    const closePinModal = () => {
        content.classList.add('scale-95', 'opacity-0');
        setTimeout(() => {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
            confirmBtn.onclick = null;
            cancelBtn.onclick = null;
            pinInput.onkeypress = null;
        }, 200);
    };
    
    window.closePinModal = closePinModal;
}

// ==================== NETWORK DETECTION ====================
window.detectNetwork = function(phone) {
    console.log('Detecting network for:', phone);
    const netSelect = document.getElementById('dataNetwork');
    const badge = document.getElementById('networkBadge');
    const networkIcons = {
        mtn: '<i class="fas fa-tower-cell text-blue-500 mr-1"></i> <span class="font-bold text-blue-600 dark:text-blue-400">MTN Network Detected</span>',
        airtel: '<i class="fas fa-signal text-red-500 mr-1"></i> <span class="font-bold text-red-600 dark:text-red-400">Airtel Network Detected</span>',
        glo: '<i class="fas fa-globe text-green-500 mr-1"></i> <span class="font-bold text-green-600 dark:text-green-400">Glo Network Detected</span>',
        '9mobile': '<i class="fas fa-mobile-alt text-pink-500 mr-1"></i> <span class="font-bold text-pink-600 dark:text-pink-400">9Mobile Network Detected</span>'
    };
    
    if (!netSelect) {
        console.error('dataNetwork select not found');
        return;
    }
    
    const cleanPhone = phone.replace(/\D/g, '');
    
    if (cleanPhone.startsWith('0803') || cleanPhone.startsWith('0806') || cleanPhone.startsWith('0810') || 
        cleanPhone.startsWith('0813') || cleanPhone.startsWith('0814') || cleanPhone.startsWith('0816')) {
        netSelect.value = 'mtn';
        if (badge) {
            badge.innerHTML = networkIcons.mtn;
            badge.className = 'text-xs mt-2 font-bold';
        }
    } else if (cleanPhone.startsWith('0802') || cleanPhone.startsWith('0808') || cleanPhone.startsWith('0812') || 
               cleanPhone.startsWith('0701') || cleanPhone.startsWith('0708')) {
        netSelect.value = 'airtel';
        if (badge) {
            badge.innerHTML = networkIcons.airtel;
            badge.className = 'text-xs mt-2 font-bold';
        }
    } else if (cleanPhone.startsWith('0805') || cleanPhone.startsWith('0807') || cleanPhone.startsWith('0811') || 
               cleanPhone.startsWith('0815') || cleanPhone.startsWith('0705')) {
        netSelect.value = 'glo';
        if (badge) {
            badge.innerHTML = networkIcons.glo;
            badge.className = 'text-xs mt-2 font-bold';
        }
    } else if (cleanPhone.startsWith('0809') || cleanPhone.startsWith('0817') || cleanPhone.startsWith('0818') || 
               cleanPhone.startsWith('0909')) {
        netSelect.value = '9mobile';
        if (badge) {
            badge.innerHTML = networkIcons['9mobile'];
            badge.className = 'text-xs mt-2 font-bold';
        }
    } else {
        if (badge) badge.innerHTML = '';
    }
    
    // Auto-select SME as default planType if none selected
    const planTypeEl = document.getElementById('planType');
    if (planTypeEl && !planTypeEl.value) {
        planTypeEl.value = 'sme';
    }
    window.loadPlans();
};

// ==================== LOAD PLANS ====================
window.loadPlans = function() {
    console.log('Loading plans...');
    const network = document.getElementById('dataNetwork')?.value;
    const planType = document.getElementById('planType')?.value;
    const select = document.getElementById('dataPlanSelect');
    const validity = document.getElementById('planValidity');
    const amountDisplay = document.getElementById('dataAmountDisplay');
    
    if (!select) {
        console.error('dataPlanSelect not found');
        return;
    }
    
    select.innerHTML = '<option value="">Select Plan</option>';
    if (validity) validity.textContent = '';
    if (amountDisplay) amountDisplay.textContent = '₦0';
    
    if (!network || !planType) {
        console.log('Network or plan type not selected');
        return;
    }
    
    console.log('Network:', network, 'Plan Type:', planType);
    
    const cookieData = loadUserFromCookie();
    console.log('Cookie data:', cookieData);
    
    if (!cookieData) {
        select.innerHTML = '<option>Please login to see plans</option>';
        return;
    }
    
    if (!cookieData.dataPrices) {
        select.innerHTML = '<option>No data prices in cookie</option>';
        return;
    }
    
    const networkPlans = cookieData.dataPrices[network];
    console.log('Network plans:', networkPlans);
    
    if (!networkPlans || !Array.isArray(networkPlans)) {
        select.innerHTML = '<option>No plans for this network</option>';
        return;
    }
    
    const filteredPlans = networkPlans.filter(plan => {
        const serverType   = (plan.plan_type || '').toLowerCase().trim();
        const selectedType = planType.toLowerCase().trim();
        // Exact match OR CG = corporate gifting
        if (selectedType === 'cg') return serverType.includes('corporate') || serverType === 'cg';
        if (selectedType === 'direct') return serverType === 'direct' || serverType === 'direct gifting';
        return serverType === selectedType;
    });
    
    console.log('Filtered plans:', filteredPlans);
    
    if (filteredPlans.length === 0) {
        select.innerHTML = '<option>No plans for this type</option>';
        return;
    }
    
    filteredPlans.forEach(plan => {
        const opt = document.createElement('option');
        opt.value = JSON.stringify({
            id: plan.id,               // plan_code (numeric ID)
            plan: plan.plan,
            plan_type: plan.plan_type,
            price: plan.price,
            validity: plan.validity,
            network: network
        });
        opt.textContent = `${plan.plan} - ₦${plan.price.toLocaleString()}`;
        select.appendChild(opt);
    });
    
    select.onchange = function() {
        if (this.value && validity && amountDisplay) {
            const p = JSON.parse(this.value);
            validity.textContent = `📅 Validity: ${p.validity}`;
            amountDisplay.textContent = `₦${p.price.toLocaleString()}`;
        }
    };
};

// ==================== DIALOG FUNCTIONS ====================
function showDialog(title, message, type = 'success') {
    const dialog = document.getElementById('customDialog');
    if (!dialog) return;
    const iconDiv = document.getElementById('dialogIcon');
    const titleEl = document.getElementById('dialogTitle');
    const msgEl = document.getElementById('dialogMessage');
    
    if (type === 'success') {
        iconDiv.innerHTML = '<i class="fas fa-check-circle text-4xl text-green-500"></i>';
        titleEl.className = 'text-xl font-bold text-green-600 dark:text-green-400 mb-2';
    } else if (type === 'error') {
        iconDiv.innerHTML = '<i class="fas fa-exclamation-circle text-4xl text-red-500"></i>';
        titleEl.className = 'text-xl font-bold text-red-600 dark:text-red-400 mb-2';
    } else {
        iconDiv.innerHTML = '<i class="fas fa-info-circle text-4xl text-blue-500"></i>';
        titleEl.className = 'text-xl font-bold text-blue-600 dark:text-blue-400 mb-2';
    }
    titleEl.textContent = title;
    msgEl.textContent = message;
    dialog.classList.remove('hidden');
    dialog.classList.add('flex');
    const content = document.getElementById('dialogContent');
    setTimeout(() => {
        content.classList.remove('scale-95', 'opacity-0');
        content.classList.add('scale-100', 'opacity-100');
    }, 10);
}

window.closeDialog = function() {
    const dialog = document.getElementById('customDialog');
    const content = document.getElementById('dialogContent');
    if (!dialog) return;
    content.classList.add('scale-95', 'opacity-0');
    setTimeout(() => {
        dialog.classList.add('hidden');
        dialog.classList.remove('flex');
    }, 200);
};

// ==================== DATA PURCHASE HANDLER (with PIN Modal) ====================


window.handleDataPurchase = async function(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const phone = document.getElementById('dataPhone')?.value;
    const planSelect = document.getElementById('dataPlanSelect');
    if (!planSelect?.value) { showToast('Please select a plan', 'error'); return; }
    if (!phone || phone.length < 10) { showToast('Valid phone number required', 'error'); return; }
    const plan = JSON.parse(planSelect.value);
    const userData = loadUserData();
    const isPinSet = userData?.userDetails?.is_setpin === true;
    if (!isPinSet) {
        showDialog('PIN Not Set', 'You need to set a transaction PIN in Security section before making purchases.', 'error');
        return;
    }
    showPinModal(async (pin) => {
        if (!pin) { showToast('Purchase cancelled', 'info'); return; }
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        try {
            const result = await window.purchaseData(phone, plan.id, pin);
            if (result.status === 'success') {
                await window.fetchUserData();
                loadUserDataToUI();
                e.target.reset();
                document.getElementById('networkBadge').innerHTML = '';
                document.getElementById('dataPlanSelect').innerHTML = '<option value="">Select Network & Type first</option>';
                document.getElementById('planValidity').textContent = '';
                document.getElementById('dataAmountDisplay').textContent = '₦0';
                showDialog('Success', `${plan.plan} data purchased for ${phone}.`, 'success');
            } else throw new Error(result.message || 'Purchase failed');
        } catch (error) {
            showDialog('Failed', error.message, 'error');
        } finally {
            btn.disabled = false;
            btn.innerHTML = 'Confirm Purchase';
        }
    });
};