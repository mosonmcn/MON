// ==================== USER DATA LOADING (LOCALSTORAGE ONLY) ====================
function loadUserDataToUI() {
    // Load from localStorage instead of cookie
    const data = loadUserData();
    if (!data) {
        console.warn('No user data found. Redirecting to login...');
        window.location.href = '../login';
        return false;
    }
    
    const user = data.userDetails;
    const transactions = data.transactions || [];
    const balance = user?.balance || 0;
    const formattedBalance = formatCurrency(balance);
    
    // Update sidebar
    const sidebarName = document.getElementById('sidebarName');
    const sidebarEmail = document.getElementById('sidebarEmail');
    const headerName = document.getElementById('headerName');
    const sidebarAvatar = document.getElementById('sidebarAvatar');
    
    if (sidebarName) sidebarName.textContent = user?.fullname || 'User';
    if (sidebarEmail) sidebarEmail.textContent = user?.email || '';
    if (headerName) headerName.textContent = user?.fullname || 'User';
    if (sidebarAvatar) {
        const avatar = (user?.fullname || 'U').split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
        sidebarAvatar.textContent = avatar;
    }
    
    // Update balance displays - always update data-original-balance
    const dashBalance = document.getElementById('dashBalance');
    const walletBalanceBig = document.getElementById('walletBalanceBig');
    
    if (dashBalance) {
        dashBalance.setAttribute('data-original-balance', formattedBalance);
        dashBalance.textContent = formattedBalance;
    }
    if (walletBalanceBig) {
        walletBalanceBig.setAttribute('data-original-balance', formattedBalance);
        walletBalanceBig.textContent = formattedBalance;
    }
    
    // Update total orders
    const dashTotal = document.getElementById('dashTotal');
    if (dashTotal) dashTotal.textContent = transactions.length;
    
    // Update profile form
    const profName = document.getElementById('profName');
    const profEmail = document.getElementById('profEmail');
    if (profName) profName.value = user?.fullname || '';
    if (profEmail) profEmail.value = user?.email || '';
    
    // Render transactions
    renderTransactions(transactions);
    
    // Store dataPrices globally for loadPlans function
    window.appData = { dataPrices: data.dataPrices || {}, transactions };
    
    // Apply balance visibility preference (after setting original balances)
    const isHidden = localStorage.getItem('balance_hidden') === 'true';
    if (isHidden) {
        document.querySelectorAll('.balance-value').forEach(el => {
            el.textContent = '••••••';
            el.classList.add('balance-hidden');
        });
    } else {
        document.querySelectorAll('.balance-value').forEach(el => {
            const original = el.getAttribute('data-original-balance');
            if (original) el.textContent = original;
            el.classList.remove('balance-hidden');
        });
    }
    
    if (typeof updateSecurityForms === 'function') {
        updateSecurityForms();
    }
    
    console.log('User data loaded successfully from localStorage');
    return true;
}

// Helper function to force refresh user data
async function refreshUserData() {
    try {
        await window.fetchUserData();
        loadUserDataToUI();
        return true;
    } catch (error) {
        console.error('Failed to refresh user data:', error);
        return false;
    }
}
