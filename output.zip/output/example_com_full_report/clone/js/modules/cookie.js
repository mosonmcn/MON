// ==================== LOCALSTORAGE FUNCTIONS (NO COOKIES) ====================

// Save entire user data (userDetails, transactions, dataPrices) to localStorage
function saveUserData(userData) {
    localStorage.setItem('MD_USER_DATA', JSON.stringify(userData));
}

// Load entire user data from localStorage
function loadUserData() {
    const raw = localStorage.getItem('MD_USER_DATA');
    if (raw) {
        try {
            return JSON.parse(raw);
        } catch(e) {
            console.error('Failed to parse user data:', e);
        }
    }
    return null;
}

// Clear all user data (logout)
function clearUserData() {
    localStorage.removeItem('MD_USER_DATA');
    localStorage.removeItem('MD_APP_DATA');
    sessionStorage.clear();
}

// For backward compatibility (if needed)
function loadUserFromCookie() {
    return loadUserData(); // now uses localStorage
}

function saveUserToCookie(userDetails) {
    // userDetails is the whole user object
    saveUserData(userDetails);
}

// Set app data (dataPrices, transactions) – you can also merge into MD_USER_DATA
function setAppData(dataPrices, transactions) {
    let userData = loadUserData() || {};
    userData.dataPrices = dataPrices;
    userData.transactions = transactions;
    saveUserData(userData);
}

function getAppData() {
    const userData = loadUserData() || {};
    return {
        dataPrices: userData.dataPrices || {},
        transactions: userData.transactions || []
    };
}

// Helper for auth status (optional)
function setAuthStatus(status) {
    localStorage.setItem('MD_AUTH_STATUS', status ? 'true' : 'false');
}

function getAuthStatus() {
    return localStorage.getItem('MD_AUTH_STATUS') === 'true';
}

function clearAuthStatus() {
    localStorage.removeItem('MD_AUTH_STATUS');
}