// ==================== UTILITIES ====================
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function formatCurrency(amount) {
    return '₦' + amount.toLocaleString('en-NG', { minimumFractionDigits: 2 });
}

function formatDate(dateString) {
    if (!dateString) return '-';
    if (dateString.includes(' ')) {
        const [datePart, timePart] = dateString.split(' ');
        return `${datePart}<br><span class="text-xs text-gray-400">${timePart}</span>`;
    }
    return dateString;
}