window.handleAirtimePurchase = async function(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    const phone = document.getElementById('airtimePhone')?.value;
    const network = document.getElementById('airtimeNetwork')?.value;
    const amount = document.getElementById('airtimeAmount')?.value;
    if (!phone || !network || !amount) { showToast('Please fill all fields', 'error'); return; }
    if (amount < 50) { showToast('Minimum airtime is ₦50', 'error'); return; }
    const userData = loadUserData();
    const isPinSet = userData?.userDetails?.is_setpin === true;
    if (!isPinSet) {
        showDialog('PIN Not Set', 'You need to set a transaction PIN in Security section before making purchases.', 'error');
        return;
    }
    showPinModal(async (pin) => {
        if (!pin) { showToast('Purchase cancelled', 'info'); return; }
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        try {
            const result = await window.purchaseAirtime(phone, network, parseFloat(amount), pin);
            if (result.status === 'success') {
                await window.fetchUserData();
                loadUserDataToUI();
                e.target.reset();
                showDialog('Success', `₦${amount} airtime sent to ${phone}.`, 'success');
            } else throw new Error(result.message || 'Purchase failed');
        } catch (error) {
            showDialog('Failed', error.message, 'error');
        } finally {
            btn.disabled = false;
            btn.innerHTML = 'Buy Airtime';
        }
    });
};