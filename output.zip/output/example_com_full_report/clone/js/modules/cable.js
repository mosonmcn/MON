// js/modules/cable.js
// Cable TV Module - Handles all cable subscription operations

/**
 * Load cable providers from API and populate select dropdown
 */
async function loadCableProviders() {
    const select = document.getElementById('cableProvider');
    if (!select) return;

    try {
        const token = getCookie('auth_token');
        if (!token) {
            showToast('Please login first', 'error');
            return;
        }

        const response = await fetch('/api/cable/providers.php?token=' + encodeURIComponent(token), {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        const result = await response.json();

        if (result.status === 'success' && result.data) {
            select.innerHTML = '<option value="">Select Provider</option>';
            result.data.forEach(provider => {
                const option = document.createElement('option');
                option.value = provider.id;
                option.textContent = provider.name;
                select.appendChild(option);
            });
        } else {
            showToast('Failed to load providers: ' + (result.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error loading cable providers:', error);
        showToast('Error loading providers. Please refresh.', 'error');
    }
}

/**
 * Load cable packages based on selected provider
 */
async function loadCablePackages() {
    const providerSelect = document.getElementById('cableProvider');
    const packageSelect = document.getElementById('cablePackage');
    const validity = document.getElementById('cableValidity');
    const providerId = providerSelect.value;

    if (!providerId) {
        packageSelect.innerHTML = '<option value="">Select Provider first</option>';
        validity.textContent = '';
        resetCableSummary();
        return;
    }

    try {
        const token = getCookie('auth_token');
        const response = await fetch(`/api/cable/packages.php?provider_id=${providerId}&token=${encodeURIComponent(token)}`, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        const result = await response.json();

        if (result.status === 'success' && result.data) {
            packageSelect.innerHTML = '<option value="">Select Plan</option>';
            result.data.packages.forEach(pkg => {
                const option = document.createElement('option');
                option.value = pkg.id;
                option.dataset.cost = pkg.cost_price;
                option.dataset.selling = pkg.selling_price;
                option.dataset.markup = pkg.markup_percentage;
                option.dataset.validity = pkg.validity || '';
                option.dataset.name = pkg.plan_name;
                option.textContent = `${pkg.plan_name} - ₦${parseFloat(pkg.selling_price).toFixed(2)}`;
                packageSelect.appendChild(option);
            });
        } else {
            showToast('Failed to load packages: ' + (result.message || 'Unknown error'), 'error');
        }
    } catch (error) {
        console.error('Error loading cable packages:', error);
        showToast('Error loading packages. Please refresh.', 'error');
    }
}

/**
 * Update cable summary when package changes
 */
function updateCableSummary() {
    const packageSelect = document.getElementById('cablePackage');
    const selected = packageSelect.options[packageSelect.selectedIndex];
    const validity = document.getElementById('cableValidity');

    if (!selected || !selected.value) {
        resetCableSummary();
        return;
    }

    const cost = parseFloat(selected.dataset.cost) || 0;
    const selling = parseFloat(selected.dataset.selling) || 0;
    const markup = parseFloat(selected.dataset.markup) || 0;
    const name = selected.dataset.name || '';

    // Update display
    document.getElementById('cablePlanName').textContent = name || '-';
    document.getElementById('cableCostPrice').textContent = `₦${cost.toFixed(2)}`;
    const charges = selling - cost;
    document.getElementById('cableCharges').textContent = `₦${charges.toFixed(2)}`;
    document.getElementById('cableTotal').textContent = `₦${selling.toFixed(2)}`;

    if (selected.dataset.validity) {
        validity.textContent = `Validity: ${selected.dataset.validity}`;
    } else {
        validity.textContent = '';
    }
}

/**
 * Reset cable summary to default values
 */
function resetCableSummary() {
    document.getElementById('cablePlanName').textContent = '-';
    document.getElementById('cableCostPrice').textContent = '₦0.00';
    document.getElementById('cableCharges').textContent = '₦0.00';
    document.getElementById('cableTotal').textContent = '₦0.00';
    document.getElementById('cableValidity').textContent = '';
}

/**
 * Verify IUC number
 */
async function verifyCableIuc() {
    const providerId = document.getElementById('cableProvider').value;
    const iuc = document.getElementById('cableIuc').value.trim();
    const infoDiv = document.getElementById('cableIucInfo');

    if (!providerId) {
        showToast('Please select a cable provider first', 'warning');
        return;
    }

    if (!iuc || iuc.length < 6) {
        showToast('Please enter a valid IUC number (at least 6 digits)', 'warning');
        return;
    }

    try {
        const token = getCookie('auth_token');
        const formData = new URLSearchParams();
        formData.append('provider_id', providerId);
        formData.append('iuc_number', iuc);
        formData.append('token', token);

        const response = await fetch('/api/cable/verify.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: formData
        });

        const result = await response.json();

        if (result.status === 'successful' && result.data && result.data.is_valid) {
            // Show customer info
            document.getElementById('cableCustomerName').textContent = result.data.customer_name || 'N/A';
            document.getElementById('cableCurrentPlan').textContent = result.data.current_plan || 'N/A';
            document.getElementById('cableExpiry').textContent = result.data.expiry_date || 'N/A';
            infoDiv.classList.remove('hidden');
            showToast('IUC verified successfully!', 'success');
        } else {
            infoDiv.classList.add('hidden');
            showToast('Invalid IUC number: ' + (result.message || 'Verification failed'), 'error');
        }
    } catch (error) {
        console.error('Error verifying IUC:', error);
        showToast('Error verifying IUC. Please try again.', 'error');
    }
}

/**
 * Handle cable purchase form submission
 */
async function handleCablePurchase(event) {
    event.preventDefault();

    const providerId = document.getElementById('cableProvider').value;
    const packageId = document.getElementById('cablePackage').value;
    const iuc = document.getElementById('cableIuc').value.trim();
    const pin = document.getElementById('cablePin').value.trim();

    // Validate all fields
    if (!providerId) {
        showToast('Please select a cable provider', 'warning');
        return;
    }
    if (!packageId) {
        showToast('Please select a plan', 'warning');
        return;
    }
    if (!iuc || iuc.length < 6) {
        showToast('Please enter a valid IUC number', 'warning');
        return;
    }
    if (!pin || pin.length !== 4) {
        showToast('Please enter your 4-digit transaction PIN', 'warning');
        return;
    }

    // Disable button to prevent double submission
    const submitBtn = document.querySelector('#cableForm button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

    try {
        const token = getCookie('auth_token');
        const formData = new URLSearchParams();
        formData.append('provider_id', providerId);
        formData.append('package_id', packageId);
        formData.append('iuc_number', iuc);
        formData.append('pin', pin);
        formData.append('token', token);

        const response = await fetch('/api/cable/buy.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: formData
        });

        const result = await response.json();

        if (result.status === 'success') {
            showToast('✅ Cable subscription successful!', 'success');
            // Update balance display
            if (window.updateBalanceDisplay) {
                window.updateBalanceDisplay(result.new_balance);
            }
            // Show transaction details
            showTransactionDetails(result);
        } else {
            showToast('❌ ' + (result.message || 'Purchase failed'), 'error');
        }
    } catch (error) {
        console.error('Error purchasing cable:', error);
        showToast('Error processing purchase. Please try again.', 'error');
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-tv"></i> Pay Now';
    }
}

// Auto-load providers when cable section becomes active
document.addEventListener('DOMContentLoaded', function() {
    // When cable section is shown, load providers
    const cableSection = document.getElementById('cable-tv');
    if (cableSection) {
        // Use MutationObserver to detect when section becomes visible
        const observer = new MutationObserver(function(mutations) {
            if (cableSection.classList.contains('active')) {
                loadCableProviders();
                observer.disconnect();
            }
        });
        observer.observe(cableSection, { attributes: true, attributeFilter: ['class'] });
    }
});