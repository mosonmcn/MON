// ==================== WALLET & BANK DETAILS ====================

function loadBankDetails() {
    const userData = loadUserData();
    const banks = userData?.userDetails?.banks || [];
    const bankDisplay = document.getElementById('bankDetailsDisplay');
    const ninForm = document.getElementById('ninVbnForm');
    const bankList = document.getElementById('bankDetailsList');
    
    if (!bankDisplay || !ninForm) return;
    
    if (banks && banks.length > 0) {
        bankDisplay.classList.remove('hidden');
        ninForm.classList.add('hidden');
        let html = '';
        banks.forEach(bank => {
            html += `
                <div class="bg-white dark:bg-gray-700 p-3 rounded-lg shadow-sm">
                    <p class="font-bold text-gray-800 dark:text-white">${escapeHtml(bank.name)}</p>
                    <p class="text-sm text-gray-600 dark:text-gray-300">Account: ${escapeHtml(bank.number)}</p>
                    <p class="text-xs text-gray-500">Name: ${escapeHtml(bank.accountName)}</p>
                </div>
            `;
        });
        bankList.innerHTML = html;
    } else {
        bankDisplay.classList.add('hidden');
        ninForm.classList.remove('hidden');
    }
}

// ──────────────────────────────────────────────────────────────
// Bank KYC – API call
// ──────────────────────────────────────────────────────────────
window.submitNinVbn = async function() {
    const idNumber = document.getElementById('ninVbnInput')?.value.trim();
    if (!idNumber || idNumber.length !== 11) {
        showToast('Please enter a valid 11-digit BVN', 'error');
        return;
    }

    showToast('Verifying with Paystack...', 'info');

    try {
        const userData = loadUserData();
        const token = userData?.userDetails?.token || '';
        if (!token) {
            showToast('Session expired. Please login again.', 'error');
            return;
        }

        const response = await fetch('../api/user/verify_kyc.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                token: token,
                type: 'bvn',
                idNumber: idNumber
            })
        });

        const result = await response.json();

        if (result.status === 'success') {
            await window.fetchUserData();
            loadUserDataToUI();
            showDialog('Verification Successful', result.message, 'success');
            loadBankDetails();
        } else {
            throw new Error(result.message || 'Verification failed');
        }
    } catch (error) {
        console.error('KYC error:', error);
        showDialog('Verification Failed', error.message, 'error');
    }
};

// ──────────────────────────────────────────────────────────────
// WALLET FUNDING (Paystack) – renamed to avoid conflict
// ──────────────────────────────────────────────────────────────
window.initiateFunding = async function() {
    const amount = parseFloat(document.getElementById('fundAmount')?.value);
    if (!amount || amount < 100) {
        showToast('Enter valid amount (min ₦100)', 'error');
        return;
    }

    showToast('Generating payment link...', 'info');

    try {
        const result = await window.initializePayment(amount);

        if (result.status === 'success' && result.data) {
            const d = result.data;
            window._fundRef = d.reference || '';

            const vs = document.getElementById('verifyStep');
            if (vs) {
                vs.classList.remove('hidden');
                vs.innerHTML = `
                    <div class="bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-4 mb-4">
                        <h3 class="font-bold text-purple-600 dark:text-purple-400 mb-3">
                            <i class="fas fa-university mr-2"></i>Payment Details
                        </h3>
                        <div class="space-y-2 text-sm">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-500">Reference:</span>
                                <div class="flex items-center gap-2">
                                    <span class="font-mono font-bold">${escapeHtml(d.reference || '—')}</span>
                                    <button onclick="navigator.clipboard.writeText('${d.reference||''}').then(()=>showToast('Copied!','success'))"
                                        class="text-xs text-purple-600 border border-purple-300 rounded px-2 py-0.5 hover:bg-purple-600 hover:text-white transition">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-500">Amount:</span>
                                <span class="font-bold text-purple-600 text-lg">₦${amount.toLocaleString()}</span>
                            </div>
                        </div>
                    </div>
                    <p class="text-xs text-gray-400 mb-4 text-center">
                        Complete the payment, then click <strong>Verify Payment</strong> to credit your wallet.
                    </p>
                    <div class="flex gap-3">
                        ${d.payment_url
                            ? `<a href="${escapeHtml(d.payment_url)}" target="_blank"
                                class="flex-1 bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 rounded-xl text-center text-sm transition">
                                <i class="fas fa-external-link-alt mr-1"></i>Pay Now</a>`
                            : '<div class="flex-1"></div>'
                        }
                        <button onclick="window.verifyFunding()" id="_verifyFundBtn"
                            class="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 rounded-xl text-sm transition">
                            <i class="fas fa-check-circle mr-1"></i>Verify Payment
                        </button>
                    </div>`;
            }
        } else {
            showToast(result.message || 'Failed to initialize payment', 'error');
        }
    } catch(err) {
        console.error('initiateFunding error:', err);
        showToast('Network error. Please try again.', 'error');
    }
};

// ──────────────────────────────────────────────────────────────
// VERIFY FUNDING (renamed to avoid conflict with API function)
// ──────────────────────────────────────────────────────────────
window.verifyFunding = async function() {
    const ref = window._fundRef || document.getElementById('verifyRef')?.value?.trim();
    if (!ref) {
        showToast('No payment reference found. Please generate a payment link first.', 'error');
        return;
    }

    const btn = document.getElementById('_verifyFundBtn');
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i>Verifying...'; }

    try {
        // This calls the API function `window.verifyPayment` from mainapi.js (not itself)
        const result = await window.verifyPayment(ref);
        if (result.status === 'success') {
            await window.fetchUserData();
            loadUserDataToUI();
            showDialog('Wallet Funded! 🎉',
                `Payment of ₦${(result.data?.amount || '').toLocaleString()} verified and credited.`,
                'success');
            document.getElementById('verifyStep')?.classList.add('hidden');
            const refInput = document.getElementById('verifyRef');
            if (refInput) refInput.value = '';
            window._fundRef = '';
        } else {
            throw new Error(result.message || 'Payment not confirmed yet. Try again shortly.');
        }
    } catch(err) {
        showDialog('Verification Failed', err.message, 'error');
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check-circle mr-1"></i>Verify Payment'; }
    }
};

window.checkPendingFunding = async function() {
    const btn = document.getElementById('checkPendingBtn');
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking...';
    
    try {
        const result = await window.checkPendingFundingAPI();
        if (result.status === 'success') {
            const pending = result.data || [];
            if (pending.length === 0) {
                showToast('No pending funding transactions found.', 'info');
            } else {
                showToast(`Found ${pending.length} pending transaction(s). Verifying...`, 'info');
                for (const p of pending) {
                    await window.verifyPayment(p.reference);
                }
                await window.fetchUserData();
                loadUserDataToUI();
                showDialog('Success', 'Pending funding verified and credited.', 'success');
            }
        } else {
            throw new Error(result.message || 'Failed to check pending funding');
        }
    } catch (error) {
        showDialog('Error', error.message, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
};

window.checkPendingFundingAPI = async function() {
    return await apiCall('user/fund/pending.php', 'POST', { action: 'check' });
};