// ==================== SIDEBAR NAVIGATION ====================
function toggleMobileMenu() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('mobileOverlay');
    if (!sidebar || !overlay) return;
    
    if (sidebar.classList.contains('-translate-x-full')) {
        sidebar.classList.remove('-translate-x-full');
        overlay.classList.remove('hidden');
    } else {
        sidebar.classList.add('-translate-x-full');
        overlay.classList.add('hidden');
    }
}

// Main function to switch sections (called from both sidebar and quick actions)
function showSection(sectionId) {
    console.log('showSection called with:', sectionId);
    
    // 1. Hide all sections
    document.querySelectorAll('.section-content').forEach(section => {
        section.classList.remove('active');
    });
    
    // 2. Show selected section
    const activeSection = document.getElementById(sectionId);
    if (activeSection) {
        activeSection.classList.add('active');
    } else {
        console.warn('Section not found:', sectionId);
        return;
    }
    
    // 3. Update page title
    const pageTitle = document.getElementById('pageTitle');
    if (pageTitle) {
        const titles = {
            'dashboard': 'Dashboard',
            'buy-data': 'Buy Data',
            'buy-airtime': 'Airtime',
            'wallet': 'Wallet',
            'transactions': 'History',
            'ai-chat': 'AI Assistant',
            'profile': 'Profile',
            'security': 'Security',
            'cable-tv': 'Cable TV',
            'electricity': 'Electricity',
            'bulk-sms': 'Bulk SMS',
            'education': 'Education',
            'referral': 'Refer & Earn'
        };
        pageTitle.textContent = titles[sectionId] || sectionId.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    }
    
    // 4. Close sidebar on mobile
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('mobileOverlay');
    if (sidebar && overlay) {
        sidebar.classList.add('-translate-x-full');
        overlay.classList.add('hidden');
    }
    
    // 5. Update active class on navigation buttons (CRITICAL)
    updateActiveNavItem(sectionId);
}

// Update which nav item has the active class
function updateActiveNavItem(sectionId) {
    // Remove active class from all nav items
    document.querySelectorAll('.nav-item').forEach(btn => {
        btn.classList.remove('bg-white/20', 'active');
    });
    
    // Find nav item with matching data-section
    let activeNav = document.querySelector(`.nav-item[data-section="${sectionId}"]`);
    
    // If not found, try to find by onclick attribute (fallback for quick actions)
    if (!activeNav) {
        document.querySelectorAll('.nav-item').forEach(btn => {
            const onclick = btn.getAttribute('onclick');
            if (onclick && onclick.includes(`'${sectionId}'`)) {
                activeNav = btn;
            }
        });
    }
    
    if (activeNav) {
        activeNav.classList.add('bg-white/20');
        activeNav.classList.add('active');
        console.log('Active nav set for:', sectionId);
    } else {
        console.warn('No nav item found for section:', sectionId);
    }
}

// Initialize sidebar event listeners
function initSidebar() {
    const navButtons = document.querySelectorAll('.nav-item[data-section]');
    console.log('Initializing sidebar, found nav buttons:', navButtons.length);
    
    navButtons.forEach(btn => {
        // Remove old listener to avoid duplicates
        btn.removeEventListener('click', sidebarClickHandler);
        btn.addEventListener('click', sidebarClickHandler);
    });
    
    // Also handle any nav buttons without data-section but with onclick (legacy)
    document.querySelectorAll('.nav-item').forEach(btn => {
        if (!btn.hasAttribute('data-section') && btn.hasAttribute('onclick')) {
            const onclick = btn.getAttribute('onclick');
            if (onclick && onclick.includes('showSection')) {
                // Already has onclick, fine
                console.log('Nav button uses onclick:', onclick);
            }
        }
    });
}

function sidebarClickHandler(e) {
    const section = this.getAttribute('data-section');
    if (section) {
        console.log('Nav clicked:', section);
        showSection(section);
    } else {
        console.warn('Nav button clicked but no data-section attribute');
    }
}

// For debugging - expose to console
window.debugSidebar = {
    updateActive: updateActiveNavItem,
    showSection: showSection,
    getActive: () => document.querySelector('.nav-item.bg-white\\/20, .nav-item.active')?.getAttribute('data-section')
};

// Auto-run when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    initSidebar();
});