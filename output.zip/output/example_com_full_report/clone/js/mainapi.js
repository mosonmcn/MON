const API_BASE_URL = '../api';

function getAuthToken() {
    const userData = loadUserData();
    return userData?.userDetails?.token || null;
}

async function apiCall(endpoint, method = 'POST', data = null) {
    const token = getAuthToken();
    const formData = new URLSearchParams();
    if (data && typeof data === 'object') {
        Object.keys(data).forEach(key => {
            if (data[key] !== undefined && data[key] !== null)
                formData.append(key, data[key]);
        });
    }
    if (token) formData.append('token', token);
    
    const options = {
        method,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: formData.toString(),
        credentials: 'same-origin'
    };
    try {
        const response = await fetch(`${API_BASE_URL}/${endpoint}`, options);
        const result = await response.json();
        if (!response.ok) {
            if (response.status === 401) {
                showNotification('Session expired. Please login again.', 'error');
                clearUserData();
                setTimeout(() => window.location.href = '../login', 1500);
                throw new Error('Unauthorized');
            }
            throw new Error(result.message || 'API request failed');
        }
        return result;
    } catch (error) {
        console.error('API Error:', error);
        showNotification(error.message || 'Network error. Please try again.', 'error');
        throw error;
    }
}

window.purchaseData = async (phone, planCode, pin) =>
    apiCall('data/buy.php', 'POST', { phone, plan_code: planCode, pin });

window.purchaseAirtime = async (phone, network, amount, pin) =>
    apiCall('airtime/buy.php', 'POST', { phone, network, amount, pin });

window.fetchUserData = async () => {
    const result = await apiCall('user/user.php', 'POST', { action: 'get' });
    if (result.status === 'success') {
        // Try to extract userDetails from direct property or from result.data
        let userDetails = result.userDetails;
        let transactions = result.transactions || [];
        let dataPrices = result.dataPrices || {};
        
        // If not found, check inside result.data (wrapped response)
        if (!userDetails && result.data) {
            userDetails = result.data.userDetails;
            transactions = result.data.transactions || [];
            dataPrices = result.data.dataPrices || {};
        }
        
        if (!userDetails) {
            console.error('Invalid user data structure:', result);
            throw new Error('Invalid user data structure from server');
        }
        
        const fullData = {
            userDetails: userDetails,
            transactions: transactions,
            dataPrices: dataPrices
        };
        saveUserData(fullData);
        setAuthStatus(true);
        return fullData;
    } 
};


window.initializePayment = async (amount) => apiCall('user/fund/initialize.php', 'POST', { amount });
window.verifyPayment = async (reference) => apiCall('user/fund/verify.php', 'POST', { reference });

//window.checkPendingFundingAPI = async () => apiCall('user/fund/pending.php', 'POST', { action: 'check' });

window.updateUserProfile = async (name, email) => apiCall('user/update_profile', 'POST', { name, email });
window.changeUserPassword = async (currentPassword, newPassword) => apiCall('user/change_password', 'POST', { current_password: currentPassword, new_password: newPassword });
window.setTransactionPin = async (pin) => apiCall('user/set_pin/pin.php', 'POST', { pin });
window.changeTransactionPin = async (oldPin, newPin) => apiCall('user/change_pin/pin.php', 'POST', { old_pin: oldPin, new_pin: newPin });
window.sendChatMessage = async (message) => apiCall('ai/chat', 'POST', { message });
window.getCableProviders = async () => apiCall('cable/providers', 'POST', {});
window.subscribeCable = async (provider, smartCard, planCode) => apiCall('cable/subscribe', 'POST', { provider, smart_card: smartCard, plan_code: planCode });
window.getElectricityProviders = async () => apiCall('electricity/providers', 'POST', {});
window.payElectricity = async (disco, meterNumber, meterType, amount) => apiCall('electricity/pay', 'POST', { disco, meter_number: meterNumber, meter_type: meterType, amount });

function showNotification(message, type) {
    if (typeof showDialog === 'function') showDialog(type==='success'?'Success':'Error', message, type);
    else if (typeof showToast === 'function') showToast(message, type);
    else alert(message);
}