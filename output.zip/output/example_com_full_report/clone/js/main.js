// Check for funding result from URL parameters
function checkFundingResult() {
    const urlParams = new URLSearchParams(window.location.search);
    const fundingStatus = urlParams.get('funding');
    const amount = urlParams.get('amount');
    
    if (fundingStatus === 'success') {
        showDialog('Funding Successful', `Your wallet has been credited with ₦${amount || '...'}.`, 'success');
        // Remove parameters from URL without reload
        const newUrl = window.location.pathname;
        window.history.replaceState({}, document.title, newUrl);
        // Refresh user data to update balance
        window.fetchUserData().then(() => loadUserDataToUI());
    } else if (fundingStatus === 'error') {
        const msg = urlParams.get('msg') || 'Payment verification failed';
        showDialog('Funding Failed', msg, 'error');
        window.history.replaceState({}, document.title, window.location.pathname);
    } else if (fundingStatus === 'already_processed') {
        showToast('This payment has already been processed.', 'info');
        window.history.replaceState({}, document.title, window.location.pathname);
    }
}


document.addEventListener('DOMContentLoaded', async () => {
    console.log('Main.js loaded - initializing dashboard...');
    
    checkFundingResult();

    // ── 1. Auth check first ──
    if (typeof checkAuthAndRedirect === 'function' && !checkAuthAndRedirect()) return;

    // ── 2. Theme + Sidebar ──
    if (typeof initTheme === 'function') initTheme();
    if (typeof initSidebar === 'function') initSidebar();

    // ── 3. Load from localStorage FIRST (cached data) ──
    let cachedDataLoaded = false;
    if (typeof loadUserDataToUI === 'function') {
        cachedDataLoaded = loadUserDataToUI();
        if (!cachedDataLoaded) return; // redirect to login
    }

    // ── 4. Balance visibility AFTER data is loaded into DOM ──
    if (typeof loadBalanceVisibilityPreference === 'function') {
        loadBalanceVisibilityPreference();
    }

    // ── 5. Bank details AFTER user data is loaded ──
    if (typeof loadBankDetails === 'function') loadBankDetails();

    // ── 6. Wrap showSection to push history state ──
    if (typeof showSection === 'function') {
        const originalShow = showSection;
        window.showSection = function(sectionId) {
            originalShow(sectionId);
            history.pushState({ section: sectionId }, '', window.location.href);
        };
        showSection('dashboard');
    }

    // ── 7. Plan loader listeners ──
    const dataNetwork = document.getElementById('dataNetwork');
    const planType = document.getElementById('planType');
    if (dataNetwork && typeof loadPlans === 'function') {
        dataNetwork.addEventListener('change', () => loadPlans());
        if (planType) planType.addEventListener('change', () => loadPlans());
    }

    // ── 8. Browser back button ──
    // Ensure handleBackButton exists (defined in other.js or sidebar.js)
    if (typeof handleBackButton === 'function') {
        window.addEventListener('popstate', handleBackButton);
    } else {
        console.warn('handleBackButton not defined – back button navigation may not work');
        // Fallback: define simple handler
        window.handleBackButton = function() {
            const activeSection = document.querySelector('.section-content.active');
            if (activeSection && activeSection.id !== 'dashboard') {
                history.pushState({ section: 'dashboard' }, '', window.location.href);
                showSection('dashboard');
                showToast('Returned to dashboard', 'info');
            }
        };
        window.addEventListener('popstate', handleBackButton);
    }
    history.replaceState({ section: 'dashboard' }, '', window.location.href);

    // ── 9. Background sync – refresh from server silently (only if fetchUserData exists) ──
    if (typeof window.fetchUserData === 'function') {
        try {
            await window.fetchUserData();
            // Reload UI with fresh data (balance, transactions, etc.)
            if (typeof loadUserDataToUI === 'function') loadUserDataToUI();
            if (typeof loadBankDetails === 'function') loadBankDetails();
            console.log('Background sync complete – UI updated with latest server data');
        } catch (e) {
            // Sync failed — cached localStorage data still showing, no crash
            console.warn('Background sync failed, using cached data:', e.message);
        }
    } else {
        console.warn('fetchUserData not defined – background sync disabled');
    }

    console.log('Dashboard initialization complete');
});